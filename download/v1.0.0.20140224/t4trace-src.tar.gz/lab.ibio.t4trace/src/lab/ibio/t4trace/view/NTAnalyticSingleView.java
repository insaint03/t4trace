package lab.ibio.t4trace.view;

import java.io.File;
import java.util.ArrayList;

import lab.ibio.t4trace.analytics.NTModel;
import lab.ibio.t4trace.analytics.NTProcess;
import lab.ibio.t4trace.analytics.NTProcess.COLORFILTER;
import lab.ibio.t4trace.analytics.NTProcess.Status;
import lab.ibio.t4trace.analytics.NTUtil;
import lab.ibio.t4trace.plug.NTView;
import lab.ibio.t4trace.view.multipart.NTModelTable;
import lab.ibio.t4trace.view.multipart.NTNodeTable;
import lab.ibio.t4trace.workbench.NTPreference;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.custom.ScrolledComposite;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.PaintEvent;
import org.eclipse.swt.events.PaintListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Canvas;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.TableItem;

public class NTAnalyticSingleView extends NTView {
	/**
	 * descriptor
	 */
	public static final String ID = "lab.ibio.t4trace.view.single";
	public static final String[] extensions = new String[]{"tif", "tiff"};
	
	private static Color COLOR_ACTIVE = null;
	private static Color COLOR_FIXED = null;
	
	private static Color COLOR_SEED = null;
	private static Color COLOR_BRANCH = null;
	private static Color COLOR_LINE = null;
	
	public NTAnalyticSingleView() {
		super(ID, extensions);
	}
	
	private void initColors(Display disp) {
		final Display _d = Display.getCurrent();
		if(COLOR_SEED==null || !_d.equals(COLOR_SEED.getDevice()) 
			|| !COLOR_SEED.equals(NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_SEED)))
			COLOR_SEED = NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_SEED);
		if(COLOR_BRANCH==null || !_d.equals(COLOR_BRANCH.getDevice())
			|| !COLOR_BRANCH.equals(NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_BRANCH)))
			COLOR_BRANCH = NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_BRANCH);
		if(COLOR_LINE==null || !_d.equals(COLOR_LINE.getDevice())
			|| !COLOR_LINE.equals(NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_LINE)))
			COLOR_LINE = NTPreference.getColorValue(_d, NTPreference.SINGLE_COLOR_LINE);
		
		if(COLOR_ACTIVE==null || !_d.equals(COLOR_ACTIVE.getDevice())
			|| !COLOR_ACTIVE.equals(NTPreference.getColorValue(_d, NTPreference.SINGLE_NODE_ACTIVE)))
			COLOR_ACTIVE = NTPreference.getColorValue(_d, NTPreference.SINGLE_NODE_ACTIVE);
		if(COLOR_FIXED==null || !_d.equals(COLOR_FIXED.getDevice())
			|| !COLOR_FIXED.equals(NTPreference.getColorValue(_d, NTPreference.SINGLE_NODE_FIXED)))
			COLOR_FIXED = NTPreference.getColorValue(_d, NTPreference.SINGLE_NODE_FIXED);
	}
	
	private int zoom = 100;
	private TabFolder tabFolder;
	private Canvas canvas;
	
	private ArrayList<NTLayer> layers;
	
	private TableViewer dispTable;
	
	private NTModelTable modelTable;
	private NTNodeTable nodeTable;
	

	@Override
	public void _createControl(Composite parent) {
		tabFolder = new TabFolder(parent, SWT.BOTTOM);
		
		// canvas pane
		final TabItem canvasPane = new TabItem(tabFolder, SWT.NONE);
		final SashForm sash = new SashForm(tabFolder, SWT.HORIZONTAL);
		
		// basic canvas & layer table pane
		_buildCanvasArea(sash, canvasPane);	
		_buildLayerPane(sash, canvasPane);
		
		// analytic pane
		modelTable = new NTModelTable(tabFolder);
		nodeTable = new NTNodeTable(tabFolder);
	}
	
	@Override
	public void open() {
		setPartName(_file.getName());
		setTitleToolTip(_file.getAbsolutePath());
		final Display disp = canvas.getDisplay();
		initColors(disp);
		
		layers = new ArrayList<NTLayer>();
		
		final int gridSize = (int)Math.pow(2, NTPreference.getInt(NTPreference.SINGLE_GRID));
		final NTProcess process = new NTProcess(_file, gridSize, COLORFILTER.RED);
		final ImageData baseImageData = process.getBaseImageData();
		addLayer("BASE IMAGE", baseImageData, true);
		
		disp.asyncExec(new Runnable() {
			private NTProcess.Listener listener = new NTProcess.Listener() {
				@Override
				protected void handle(Status status) {
					if(NTProcess.Status.READY == status) {
						// build initial signal image
						_drawSignalLayer(disp, "BASE SIGNAL", process, false);
					}
					else if(NTProcess.Status.ROUND_COMPLETE == status) {
						// build result signal image
						_drawSignalLayer(disp, "FINAL SIGNAL", process, false);
					}
					else if(NTProcess.Status.DONE == status) {
						// build result model
						_drawModelLayer(disp, "RESULT", process, true);
						nodeTable.addInput(process);
					}
					else if(NTProcess.Status.ROUND_ITERATING == status) {
						_drawSignalLayer(disp, String.format("BOUND %.0f", process.getBoundSize()), process, false);
					}
						
				}
			};
			
			@Override
			public void run() {
				// run
				process.runWithListener(listener, 0);
				
				
				for(NTModel model : process.getModels())
					modelTable.appendItem(process, model);
				
				modelTable.refresh();
			} 
		});
		
		// image out
		dispTable.setInput(layers);
		
		// default select all
		final TableItem[] items = dispTable.getTable().getItems();
		
		for(int i=0; i<items.length; i++) {
			items[i].setChecked(i==0);
		}
	}
	
	private void _addMenuItem(Menu menu, String label, SelectionListener listener) {
		final MenuItem item = new MenuItem(menu, SWT.PUSH);
		item.setText(label);
		item.addSelectionListener(listener);
	}

	
	
	
	private void _buildCanvasArea(final SashForm sash, final TabItem canvasPane) {
		final ScrolledComposite wrapper = new ScrolledComposite(sash, SWT.H_SCROLL | SWT.V_SCROLL);
		wrapper.setLayout(new GridLayout());
		
		canvas = new Canvas(wrapper, SWT.BORDER);
		canvas.setLayoutData(new GridData(SWT.CENTER, SWT.CENTER, false, false));
		canvas.setBackground(canvas.getDisplay().getSystemColor(SWT.COLOR_BLACK));
		wrapper.setContent(canvas);
		canvasPane.setText("Canvas");
		
		_buildCanvasPopupMenu();
		
		_attachCanvasListeners();
	}
	
	private void _buildLayerPane(final SashForm sash, final TabItem canvasPane) {
		dispTable = new TableViewer(sash, SWT.CHECK | SWT.V_SCROLL | SWT.BORDER | SWT.SINGLE);
		canvasPane.setControl(sash);
		sash.setWeights(new int[]{75, 25});
		
		dispTable.getTable().addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(e.detail == SWT.CHECK) {
					canvas.redraw();
				}
			}
		});
		dispTable.setContentProvider(new IStructuredContentProvider() {
			@Override
			public void inputChanged(Viewer viewer, Object oldInput, Object newInput) { }
			@Override
			public void dispose() {	}
			
			@SuppressWarnings({ "rawtypes", "unchecked" })
			@Override
			public Object[] getElements(Object inputElement) {
				if(inputElement instanceof ArrayList) {
					final ArrayList list = (ArrayList)inputElement;
					return list.toArray(new Object[list.size()]);
				}
				return new Object[]{inputElement};
			}
		});
		
		dispTable.setLabelProvider(new ITableLabelProvider() {
			@Override
			public void removeListener(ILabelProviderListener listener) { }
			@Override
			public boolean isLabelProperty(Object element, String property) { return false; }
			@Override
			public Image getColumnImage(Object element, int columnIndex) { return null;	}
			@Override
			public void dispose() {	}
			@Override
			public void addListener(ILabelProviderListener listener) { }
			@Override
			public String getColumnText(Object element, int columnIndex) {
				if(element instanceof NTLayer) {
					final NTLayer layer = (NTLayer) element;
					return layer.name;
				}
				return null;
			}
		});
	}
	
	private void _buildCanvasPopupMenu() {
		final Menu popup = new Menu(canvas);
		_addMenuItem(popup, "&Selections to Images", new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				final DirectoryDialog dlg = new DirectoryDialog(canvas.getShell());
				dlg.setText("Direct Folder to save images");
				dlg.setMessage("Select Folder to save layers");
				final String path = dlg.open();
				if(path==null) return;
				
				for(int i=0; i<dispTable.getTable().getItemCount(); i++) {
					if(dispTable.getTable().getItem(i).getChecked()) {
						final NTLayer selectedLayer = layers.get(i);
						final String toSavePath = String.format("%s%s%s.png", path, File.separator, selectedLayer.name);
						NTUtil.saveAs(selectedLayer.img, toSavePath, NTUtil.DEFAULT_IMAGE_EXTENSION);
					}
				}
			}
		});
		_addMenuItem(popup, "&Current to Image...", new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				final FileDialog dlg = new FileDialog(canvas.getShell());
				dlg.setFilterExtensions(new String[]{"*.png"});
				String path = dlg.open();
				
				if(path!=null) {
					final ImageLoader loader = new ImageLoader();
					if(!path.toLowerCase().endsWith(".png"))
						path += ".png"; 
					final Point canvasSize = canvas.getSize();
					final Image image = new Image(canvas.getDisplay(), canvasSize.x, canvasSize.y);
					final GC gc = new GC(image);
					canvas.print(gc);
					gc.dispose();
					
					loader.data = new ImageData[]{image.getImageData()}; 
					loader.save(path, SWT.IMAGE_PNG);
				}
				
			};
		});
		new MenuItem(popup, SWT.SEPARATOR);
		_addMenuItem(popup, "Refresh", new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				open();
			}
		});
		
		canvas.setMenu(popup);
	}
	
	private void _attachCanvasListeners() {
		canvas.addPaintListener(new PaintListener() {
			@Override
			public void paintControl(PaintEvent e) {
				
				final TableItem[] items = dispTable.getTable().getItems();
				final GC gc = new GC(canvas);
				for(int i=0; i<items.length; i++) {
					if(items[i].getChecked()) {
						final NTLayer _draw = layers.get(i);
						if(_draw.img!=null) {
							gc.drawImage(_draw.img, 0, 0);
						}
					}
				}
			}
		});
		
		canvas.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.stateMask == SWT.CTRL) {
					if(zoom<10000 && e.keyCode == SWT.ARROW_UP)
						zoom += 10;
					else if(5<zoom && e.keyCode == SWT.ARROW_DOWN)
						zoom -= 10;
					else if(e.keyCode == '0')
						zoom = 100;
					
					// reshape images
					for(NTLayer _l : layers) {
						final ImageData org = _l.base; 
						final ImageData resized = _l.base.scaledTo(org.width*zoom/100, org.height*zoom/100);
						
//						final Point cSize = canvas.getSize();
//						if(cSize.x!=resized.width || cSize.y!=resized.height) {
						canvas.setSize(resized.width, resized.height);
//						}
						_l.img = new Image(canvas.getDisplay(), resized);
					}
					
					canvas.redraw();
				}
			}
		});
		
		canvas.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseUp(MouseEvent e) {
				// on right click, open popup menu
				switch(e.button) {
				case 1: // left
					break;
				case 2: // middle
				case 3: // right
					canvas.getMenu().setVisible(true);
					break;
				
				// sp. buttons
				case 4:
				case 5:
				default: 
				
				}
			}
		});
	}

	@Override
	public void setFocus() {
	}
	
	
	public NTLayer addLayer(String layerName, ImageData data, boolean defaultVisible) {
		final Display d = canvas.getDisplay();
		final Point cSize = canvas.getSize();
		
		final NTLayer layer = new NTLayer(layerName, new Image(d, data));
		if(cSize.x<data.width || cSize.y<data.height) {
			cSize.x = Math.max(cSize.x, data.width);
			cSize.y = Math.max(cSize.y, data.height);
			canvas.setSize(cSize);
		}
		
		layers.add(layer);
		
		dispTable.refresh();
		
		final int idx = layers.indexOf(layer);
		if(idx<dispTable.getTable().getItemCount()) {
			final TableItem item = dispTable.getTable().getItem(idx);
			if(item!=null && !item.getChecked()) {
				item.setChecked(defaultVisible);
				canvas.redraw();
			}
		}
		
		return layer;
	}
	
	private void _drawModelLayer(Display disp, String title, NTProcess process, boolean defaultVisible) {
		initColors(disp);
//		final IPreferenceStore pStore = Activator.getDefault().getPreferenceStore();
		final Image img = process.drawModels(disp, COLOR_SEED, COLOR_BRANCH, COLOR_LINE, 1);
		
		
		final ImageData layerData = img.getImageData();
		layerData.transparentPixel = -256;
		addLayer(title, layerData, defaultVisible);
	}
	
	private void _drawSignalLayer(Display disp, String title, NTProcess process, boolean defaultVisible) {
		initColors(disp);
		// save for transparent background
		final Image img = 		
			process.drawSnapshot(disp, COLOR_ACTIVE, COLOR_FIXED);
		
		final ImageData layerData = img.getImageData();
		layerData.transparentPixel = -256;
		addLayer(title, layerData, defaultVisible);
		
	}
	
	@Override
	protected String windowTitle() {
		return String.format("T4Trace Single> %s",  _file.getAbsolutePath());
	}
	
	
	private static class NTLayer {
		final String name;
		Image img;
		ImageData base;
//		final ColorFilter color;
//		
//		final ImageData data;
//		
		
		NTLayer(String name, Image img) {
			this.name = name;
			this.img = img;
			this.base = img.getImageData();
		}
		
	}
}



