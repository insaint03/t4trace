package lab.ibio.t4trace.handler;

import java.io.File;

import lab.ibio.t4trace.view.NavigationView;
import lab.ibio.t4trace.workbench.Application;
import lab.ibio.t4trace.workbench.NTPreference;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.swt.widgets.DirectoryDialog;

public class ActionWorkspace extends AbstractHandler {
	
	public static final String ID = "lab.ibio.t4trace.action.workspace";

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		final DirectoryDialog dlg = new DirectoryDialog(Application.shell());
		dlg.setText("Set Workspace");
		dlg.setMessage("Select a root folder for browsing");
		
		final String result = dlg.open();
		if(result!=null) {
			final File file = new File(result);
			final NavigationView navigator = (NavigationView) Application.showView(NavigationView.ID);
			if(navigator!=null && file.isDirectory() && file.canRead() && file.canWrite()) {
				navigator.setWorkspace(file);
				NTPreference.setString(NTPreference.WORKSPACE, file.getAbsolutePath());
			}
		}
		return null;
	}
}
