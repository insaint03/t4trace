package lab.ibio.t4trace.plug;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.TreeMap;

import lab.ibio.t4trace.view.NTAnalyticMultiView;
import lab.ibio.t4trace.view.NTAnalyticSingleView;
import lab.ibio.t4trace.view.NTTableView;
import lab.ibio.t4trace.workbench.Application;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewSite;
import org.eclipse.ui.part.ViewPart;


public abstract class NTView extends ViewPart {
	protected static String HASHKEY_DIR = File.pathSeparator;
	
	private static long HASHKEY_RADIX = 0x10000L;
	private static TreeMap<String, Integer> _viewRefMap = new TreeMap<String, Integer>();
	private static TreeMap<Long, String> _refViewMap = new TreeMap<Long, String>();
	
	protected File _file;
	
	public static void initiate() {
		new NTAnalyticSingleView();
		new NTTableView();
		new NTAnalyticMultiView();
	}
	
	@SuppressWarnings("unused")
	private NTView() {
		// register sub-views
	}
	
	public static FileFilter NTFilter = new FileFilter() {
		@Override
		public boolean accept(File file) {
			return file.isDirectory() || _viewRefMap.containsKey(getExtension(file));
		}
	};
	
	private static long hashKey(int multi, int mod) {
		return HASHKEY_RADIX * multi + mod;
	}
	
	protected static ArrayList<String> getAcceptableViewIds(File file) {
		final String extKey = getExtension(file);
		if(_viewRefMap.containsKey(extKey)) {
			final ArrayList<String> viewIds = new ArrayList<String>();
			final int modular = _viewRefMap.get(extKey);
			int multiplier = 0;
			while(_refViewMap.containsKey(hashKey(multiplier, modular)))
				viewIds.add(_refViewMap.get(hashKey(multiplier, modular)));
			
			if(0 < viewIds.size())
				return viewIds;
		}
		
		return null;
	}
	
	public static String getFirstViewId(File file) {
		final String extKey = getExtension(file);
		if(_viewRefMap.containsKey(extKey)) {
			return _refViewMap.get(hashKey(0, _viewRefMap.get(extKey)));
		}
		
		return null;
	}
	
	
	/**
	 * descriptor functions
	 * 
	 */
	protected NTView(String id, String[] acceptExtensions) {
		for(final String ext : acceptExtensions) {
			final String extRef = ext.toLowerCase();
			if(!_viewRefMap.containsKey(extRef)) {
				final int modular = _viewRefMap.size();
				int multiplier = 0;
				_viewRefMap.put(extRef, modular);
				// loop while empty space
				while(_refViewMap.containsKey(hashKey(multiplier, modular))) multiplier++;
				
				_refViewMap.put(hashKey(multiplier, modular), id);
			}
		}
		
	}
	
	protected abstract void open();
	protected abstract void _createControl(Composite parent);
	protected abstract String windowTitle();
	
	public void createPartControl(Composite parent) {
		_createControl(parent);
		
		final IViewSite site = (IViewSite) getSite();
		this._file = idString2File(site.getSecondaryId());
		final Shell sh = Application.window().getShell();
		sh.setText(windowTitle());
		if(_file.canRead()) 
			open();
	};
	
	
	
	@Override
	public void setFocus() {
		Application.shell().setDefaultButton(null);
	}
	
	public static String file2IdString(File file) {
		return file.getAbsolutePath().replace(':', '#');
	}
	
	
	public static File idString2File(String idStr) {
		return new File(idStr.replace('#', ':'));
	}
	
	protected static String getExtension(File file) {
		if(file.isFile()) {
			final String filename = file.getName();
			final int lastIndex = filename.lastIndexOf('.');
			if(0<=lastIndex && lastIndex != filename.length())
				return filename.substring(lastIndex+1).toLowerCase();
			else
				return null;
		}
		else {
			return HASHKEY_DIR;
		}
	}

}
