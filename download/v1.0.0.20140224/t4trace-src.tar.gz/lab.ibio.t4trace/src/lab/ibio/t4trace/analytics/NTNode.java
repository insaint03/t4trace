package lab.ibio.t4trace.analytics;

import java.util.ArrayList;

public class NTNode implements Comparable<NTNode> {
	
	public static final NTNode buildFromPxs(int[][] pixels, int y, int x, int gridSize, int threshold) {
		double vectorX = 0;
		double vectorY = 0;
		double sValue = 0;
		for(int _y=y; _y<y+gridSize; _y++) {
			for(int _x=x; _x<x+gridSize; _x++) {
				if(NTUtil.inBound(pixels, _y, _x) && threshold<pixels[y][x]) {
					int dx = _x-(x+gridSize/2);
					int dy = _y-(y+gridSize/2);
					int mass = pixels[_y][_x];
					
					vectorX += mass * dx;
					vectorY += mass * dy;
					sValue += mass;
				}
			}
		}
		
		if(sValue<threshold)
			return null;
		
		final double cPointX = x+gridSize/2 + vectorX/sValue;
		final double cPointY = y+gridSize/2 + vectorY/sValue;
		
		return new NTNode(cPointX, cPointY, sValue);
	}

	double _x;
	double _y;
	double _vx;
	double _vy;
	double _mass;
	boolean active;
	
	double _radius;
	
	public NTNode(double x, double y, double mass) {
		this._x = x;
		this._y = y;
		this._vx = 0;
		this._vy = 0;
		this._mass = Math.abs(mass);
		this.active = true;
		this._radius = Double.NaN;
	}
	
	public double radius(int threshold, boolean refresh) {
		if(Double.isNaN(_radius) || refresh) {
			this._radius = Math.sqrt(_mass)/(threshold);
		} 
		
		return this._radius; 
	}
	
	public void fix() {
		this.active = false;
	}
	
	public double estimedRad(double[] reg) {
		if(0<reg[8])
			return Math.abs(this._y - reg[2]*_x + reg[1]);
		else
			return Math.abs(this._x = reg[2]*_y + reg[1]);
	}
	
	public void fit(double[] reg) {
		if(0<reg[8])
			this._y = reg[2]*_x + reg[1];
		else
			this._x = reg[2]*_y + reg[1];
	}
	
	public boolean act() {
		if(active) {
			this._x += this._vx;
			this._y += this._vy;
			
			this._vx = 0;
			this._vy = 0;
			
			return true;
		}
		return false;
	}
	
	
	public double distance(double x, double y) {
		final double dx = this._x() - x;
		final double dy = this._y() - y;
		return Math.sqrt(dx*dx + dy*dy);
	}
	
	public double distance(NTNode other) {
		return distance(other._x(), other._y());
	}
	
	public int merge(ArrayList<NTNode> others) {
		int count = 0;
		double mm = 0;
		double dx = 0;
		double dy = 0;
		for(NTNode o : others) {
			if(o.isActive()) {
				count += 1;
				mm += o._mass;
				dx += o._mass*(o._x - this._x);
				dy += o._mass*(o._y - this._y);
			}
		}
		this._mass += mm;
		this._x += dx/_mass;
		this._y += dy/_mass;
		return count;
	}
	
	public boolean collision(NTNode other, int threshold, double criticalDistance) {
		if(other.isActive()
		&& other._mass <= _mass
		&& distance(other)<=criticalDistance ) {
			this.gravity(other, 0.01, threshold);
			this.act();
			this._mass += other._mass;
			
			return true;
		}
		
		return false;
	}
	
	public void gravity(NTNode other, double k, int threshold) {
		final double dx = this._x() - other._x();
		final double dy = this._y() - other._y();
		final double dd = dx*dx + dy*dy;
		final double om = Math.max(0.5, other._mass/threshold);
		final double mm = Math.max(0.5, this._mass/threshold);
		final double fx = k * om * dx/dd;
		final double fy = k * om * dy/dd;
		this._vx -= fx/mm;
		this._vy -= fy/mm;
	}
	
	public double _x() {
		return this._x;
	}
	
	public double _y() {
		return this._y;
	}
	
	public int x() {
		return (int)Math.round(_x());
	}
	
	public int y() {
		return (int)Math.round(_y());
	}
	
	
	public double mass() {
		return _mass;
	}
	
	public boolean isActive() {
		return this.active;
	}
	

	@Override
	public int compareTo(NTNode o) {
		if(this._mass < o._mass)
			return +1;
		else if(this._mass > o._mass)
			return -1;
		else
			return 0;
	}
	
	@Override
	public String toString() {
		return String.format("[%.2f] (%.1f,%.1f) %s", _mass, _x, _y, Boolean.toString(active));
	}
	
	public static enum Type {
		Soma,
		Branch,
		Trunk,
		Terminal,
	}
}
