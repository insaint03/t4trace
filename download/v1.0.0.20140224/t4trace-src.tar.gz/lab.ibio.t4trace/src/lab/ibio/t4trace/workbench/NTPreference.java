package lab.ibio.t4trace.workbench;

import org.eclipse.jface.preference.ColorFieldEditor;
import org.eclipse.jface.preference.FieldEditorPreferencePage;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.preference.ScaleFieldEditor;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Group;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPreferencePage;

public class NTPreference extends FieldEditorPreferencePage implements IWorkbenchPreferencePage {
	
	public static final String WORKSPACE = "T4TRACE.ANALYTICS.PATH";
	
	public static final String SINGLE_GRID = "T4TRACE.SINGLE.GRIDSIZE";
	public static final String SINGLE_COLOR_SEED = "T4TRACE.SINGLE.COLOR.SEED";
	public static final String SINGLE_COLOR_BRANCH = "T4TRACE.SINGLE.COLOR.BRANCH";
	public static final String SINGLE_COLOR_LINE = "T4TRACE.SINGLE.COLOR.LINE";
	
	public static final String SINGLE_NODE_ACTIVE = "T4TRACE.SINGLE.ACTIVE";
	public static final String SINGLE_NODE_FIXED = "T4TRACE.SINGLE.FIXED";
	
	public static final String MULTI_COLOR_SEED = "T4TRACE.MULTI.COLOR.SEED";
	public static final String MULTI_COLOR_BRANCH = "T4TRACE.MULTI.COLOR.BRANCH";
	public static final String MULTI_COLOR_LINE = "T4TRACE.MULTI.COLOR.LINE";
	
	public static final void initateDefault() {
		final IPreferenceStore store = Activator.getDefault().getPreferenceStore();
		store.setDefault(SINGLE_NODE_ACTIVE, "255,53,0");
		store.setDefault(SINGLE_NODE_FIXED, "0,182,79");
		
		store.setDefault(SINGLE_COLOR_SEED, "255,78,78");
		store.setDefault(SINGLE_COLOR_BRANCH, "189,245,75");
		store.setDefault(SINGLE_COLOR_LINE, "8,94,94");
		
		store.setDefault(MULTI_COLOR_SEED, "241,41,41");
		store.setDefault(MULTI_COLOR_BRANCH, "134,169,64");
		store.setDefault(MULTI_COLOR_LINE, "8,94,94");
		
		store.setDefault(WORKSPACE, "samples");
	}
	
	
	public static Color getColorValue(Device d, String prefKey) {
		String[] vs = NTPreference.getString(prefKey).split(",");
		
		final int r = Integer.parseInt(vs[0]);
		final int g = Integer.parseInt(vs[1]);
		final int b = Integer.parseInt(vs[2]);
		
		return new Color(d, r, g, b);
	}
	
	public NTPreference() {
		super(GRID);
		final IPreferenceStore store = Activator.getDefault().getPreferenceStore();
		
		setPreferenceStore(store);
		
	}
	
	public static String getString(String name) {
		return Activator.getDefault().getPreferenceStore().getString(name);
	}
	public static void setString(String name, String value) {
		Activator.getDefault().getPreferenceStore().setValue(name, value);
	}
	
	public static int getInt(String name) {
		return Activator.getDefault().getPreferenceStore().getInt(name);
	}
	public static void setInt(String name, int value) {
		Activator.getDefault().getPreferenceStore().setValue(name, value);
	}
			
	private Group _gridGroup(Composite parent, String title, int grids, boolean widthIdentical) {
		final Group group = new Group(parent, SWT.NONE);
		group.setText(title);
		
		final GridLayout layout = new GridLayout(grids, widthIdentical);
		layout.marginWidth = 10;
		layout.marginHeight = 10;
		layout.horizontalSpacing = 15;
		layout.verticalSpacing = 15;
		layout.marginLeft = 20;
		layout.marginRight = 20;
		
		group.setLayout(layout);
		group.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, false));
		
		return group;
	}
	

	@Override
	public void init(IWorkbench workbench) {
//		final IPreferenceStore store = getPreferenceStore();
//		store.setDefault(SINGLE_NODE_ACTIVE, "255,53,0");
//		store.setDefault(SINGLE_NODE_FIXED, "0,182,79");
//		
//		store.setDefault(SINGLE_COLOR_SEED, "255,78,78");
//		store.setDefault(SINGLE_COLOR_BRANCH, "189,245,75");
//		store.setDefault(SINGLE_COLOR_LINE, "140,226,226");
//		
//		store.setDefault(MULTI_COLOR_SEED, "241,41,41");
//		store.setDefault(MULTI_COLOR_BRANCH, "134,169,64");
//		store.setDefault(MULTI_COLOR_LINE, "8,94,94");
		
//		store.setValue(SINGLE_NODE_ACTIVE, "255,53,0");
//		store.setValue(SINGLE_NODE_FIXED, "0,182,79");
//		
//		store.setValue(SINGLE_COLOR_SEED, "255,78,78");
//		store.setValue(SINGLE_COLOR_BRANCH, "189,245,75");
//		store.setValue(SINGLE_COLOR_LINE, "140,226,226");
//		
//		store.setValue(MULTI_COLOR_SEED, "241,41,41");
//		store.setValue(MULTI_COLOR_BRANCH, "134,169,64");
//		store.setValue(MULTI_COLOR_LINE, "8,94,94");
	}
	
	@Override
	public void createControl(Composite parent) {
		super.createControl(parent);
	}

	@Override
	protected void createFieldEditors() {
		// single analytic group
		final Group singleGroup = _gridGroup(getFieldEditorParent(), "Analytics Single", 1, false);
		addField(new ScaleFieldEditor(SINGLE_GRID, "Grid Size", singleGroup));
		addField(new ColorFieldEditor(SINGLE_NODE_ACTIVE, "Active Node", singleGroup));
		addField(new ColorFieldEditor(SINGLE_NODE_FIXED, "Fixed Node", singleGroup));
		
		addField(new ColorFieldEditor(SINGLE_COLOR_SEED, "Seed", singleGroup));
		addField(new ColorFieldEditor(SINGLE_COLOR_BRANCH, "Branch", singleGroup));
		addField(new ColorFieldEditor(SINGLE_COLOR_LINE, "Line", singleGroup));
		
		// multi analytic group
		final Group multiGroup = _gridGroup(getFieldEditorParent(), "Analytics Multi", 1, true);
		addField(new ColorFieldEditor(MULTI_COLOR_SEED, "Seed", multiGroup));
		addField(new ColorFieldEditor(MULTI_COLOR_BRANCH, "Branch", multiGroup));
		addField(new ColorFieldEditor(MULTI_COLOR_LINE, "Line", multiGroup));
	}
		
	
}
