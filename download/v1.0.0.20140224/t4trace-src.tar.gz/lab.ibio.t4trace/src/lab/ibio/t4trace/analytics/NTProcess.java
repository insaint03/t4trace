package lab.ibio.t4trace.analytics;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

import org.eclipse.swt.SWTException;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Device;
import org.eclipse.swt.graphics.GC;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;

public final class NTProcess implements Serializable {
//	private static double K = 0.01;
	
	private static final long serialVersionUID = -2319322621768175519L;
	
	private final File baseFile;
	private ImageData baseImage;
	private COLORFILTER colorFilter;
//	private ImageData procImage;
	private int[][] pixels;
	private ArrayList<NTNode> nodes;
	private int threshold;
	private int boundaryIntensity;
	private int gridSize;
	
	private HashSet<NTNode> toRemove = new HashSet<NTNode>();
	private HashSet<NTNode> toFix = new HashSet<NTNode>();
	
	private int initPtCnt;
	private int finPtCnt;
	
	private final int _roundLimit;
	private final double _tolerance;
	private double _distBound;
	
	
	private long _timeCost = 0;
	
	private ArrayList<NTModel> models;

	
	
	public NTProcess(File imageFile, int grid, COLORFILTER colorFilter) throws SWTException {
		this.baseFile = imageFile;
		
//		this.baseImage = _loadImageData();
		this.gridSize = grid;
		this.colorFilter = colorFilter;
		
		this._tolerance = 0.5;
		
		// load image data
		final ImageLoader loader = new ImageLoader();
		final ImageData[] data = loader.load(this.baseFile.getAbsolutePath());
		
		if(data.length<1) {
			throw new SWTException("NULL IMAGE DATA");
		}
		
		
		this.baseImage = data[0];
		this._roundLimit = (int)(Math.log(Math.min(baseImage.width, baseImage.height)/4)/Math.log(2));
	}
	
	public long getTimeCost() {
		if(models==null)
			return -1;
		else
			return _timeCost;
	}
	
	public int getGridSize() {
		return this.gridSize;
	}
	
	public double getBoundSize(){
		return this._distBound;
	}
	
	
	public int getThreashold() {
		return this.threshold;
	}
	
	public int getBoundaryIntensity() {
		return this.boundaryIntensity;
	}
	
	public int getInitialPointCount() {
		return initPtCnt;
	}
	
	public int getFinalPointCount() {
		return finPtCnt;
	}
	
	public double getLongestModel() {
		double longest = -1;
		
		if(models!=null) {
			for(NTModel mm : models) {
				if(longest<mm.getTotalLength()) 
					longest = mm.getTotalLength();
			}
		}
		
		return longest;
	}
	
	public double getModelTotalLen() {
		double sum = 0;
		if(models!=null) {
			for(NTModel mm : models) {
				sum += mm.getTotalLength();
			}
		}
		
		return sum;
	}
	
	
	public void runWithListener(Listener listener, int roundLimit) {
		final long tick = System.currentTimeMillis();
		
		initialize();
		
		if(listener!=null) 
			listener.handle(Status.READY);
		
		// force round to converge
		_distBound = gridSize;
		
		for(int round=0; round<_roundLimit; round++) {
			
			forceDirectedRound();
			
			for(NTNode fNode : toFix)
				fNode.fix();
			
			
			nodes.removeAll(toRemove);
			if(toRemove.isEmpty() && toFix.isEmpty())
				break;
			
			if(listener!=null)
				listener.handle(Status.ROUND_ITERATING);
			
			// for next round
			_distBound *= 2;
			toRemove.clear();
			toFix.clear();
		}
		
		if(listener!=null) 
			listener.handle(Status.ROUND_COMPLETE);
		
		// count pt at finalize
		finPtCnt = nodes.size();
		
		//build models
		buildNeuronModels();
		
		if(listener!=null) 
			listener.handle(Status.DONE);
		
		this._timeCost += System.currentTimeMillis() - tick;
	}
	
	public void run(int roundLimit) {
		runWithListener(null, roundLimit);
	}
	
	private void initialize() throws SWTException {
		final int[][] rawPixels = new int[baseImage.height][baseImage.width];
		this.pixels = new int[baseImage.height][baseImage.width];
		
		// gray filtering
		for(int y=0; y<rawPixels.length; y++) {
			for(int x=0; x<rawPixels[y].length; x++) {
				rawPixels[y][x] = colorFilter.filter(baseImage.getPixel(x, y));
			}
		}
		
		// thresholding
		this.threshold = Math.max(16, NTUtil.autoThresholding(rawPixels));
		this.boundaryIntensity = Math.max(4, threshold/4); 
		
		for(int y=0; y<rawPixels.length; y++) {
			pixels[y] = Arrays.copyOf(rawPixels[y], rawPixels[y].length);
		}
		
		// build NTNodes
		this.nodes= new ArrayList<NTNode>();
		for(int y=0; y<pixels.length; y+=gridSize) {
			for(int x=0; x<pixels[y].length; x+=gridSize) {
				final NTNode nt = NTNode.buildFromPxs(pixels, y, x, gridSize, boundaryIntensity);
				if(nt!=null) {
					nodes.add(nt);
				}
			}
		}
		
		// init point numbers
		initPtCnt = nodes.size();
	}
	
	public ImageData getBaseImageData() {
		return this.baseImage;
	}
	
	public File getInputFile() {
		return this.baseFile;
	}
	
	public String getInputFilename(boolean withoutExtension) {
		final String fileName = this.baseFile.getName();
		if(withoutExtension && 0<fileName.lastIndexOf('.')) {
			return fileName.substring(0, fileName.lastIndexOf('.'));
		} else {
			return fileName;
		}
	}
	
	public int[][] getPixels() {
		return this.pixels;
	}
	
	public ArrayList<NTNode> getNodes() {
		return this.nodes;
	}
	
	public ArrayList<NTModel> getModels() {
		return this.models;
	}
	
	public Image drawSnapshot(Device d, Color active, Color fixed) {
		final Image sImg = new Image(d, baseImage.width, baseImage.height);
		final GC gc = new GC(sImg);
		
		for(NTNode node : nodes) {
			
			final Color color = node.isActive()?active:fixed;
			gc.setForeground(color);
			gc.setBackground(color);
			
			final int rad = (int)node.radius(threshold, true);
			if(rad<=1)
				gc.drawPoint(node.x(), node.y());
			else
				gc.drawOval(node.x()-rad, node.y()-rad, 2*rad, 2*rad);
		}
		gc.dispose();
		return sImg;
	}
	
	public Image drawModels(Device d, Color seed, Color branch, Color line, int compression) {
		final Image mImg = new Image(d, baseImage.width/compression, baseImage.height/compression);
		final GC gc = new GC(mImg);
		gc.setForeground(line);
		
		for(NTModel mm : models) {
			if(1<mm.getTotalLength())
				mm.drawImage(gc, seed, branch, line, threshold, compression);
		}
		
		
		gc.dispose();
		return mImg;
	}
	
	public void buildNeuronModels() {
		// clear overlaps
		toRemove.clear();
		for(int i=0; i<nodes.size(); i++) {
			final NTNode iNode = nodes.get(i);
			final double rad = iNode.radius(threshold, true);
			
			if(pixels[iNode.y()][iNode.x()]<Math.max(16, threshold/2)) {
				toRemove.add(iNode);
				continue;
			}
			
			for(int j=0; j<nodes.size(); j++) {
				final NTNode jNode = nodes.get(j);
				final double dist = iNode.distance(jNode);
				if(i!=j && !toRemove.contains(iNode) && !toRemove.contains(jNode)) {
					if((dist<rad && jNode.mass()<=jNode.mass())
					|| (jNode.isActive() && dist<2*rad)){
						iNode._mass += jNode._mass;
						toRemove.add(jNode);
						break;
					}
				}
			}
		}
		
		nodes.removeAll(toRemove);
		
		Collections.sort(nodes);
		
		final double[][] adjacency = NTUtil.connectivity(pixels, nodes, threshold, boundaryIntensity);
		this.models = new ArrayList<NTModel>();
		final ArrayList<Integer> modelNodes = new ArrayList<Integer>();
		
		final ArrayList<NTNode> proceed = new ArrayList<NTNode>();
		final HashSet<Integer> visiteds = new HashSet<Integer>();
		
		for(NTNode seed : nodes) {
			final int seedIdx = nodes.indexOf(seed);
			if(visiteds.contains(seedIdx)) continue;
			
			proceed.add(seed);
			
			while(!proceed.isEmpty()) {
				final int getIdx = 0;
				final NTNode node = proceed.remove(getIdx);
				final int nIdx = nodes.indexOf(node);

				modelNodes.add(nIdx);
				visiteds.add(nIdx);
				
				for(int n=0; n<adjacency[nIdx].length; n++) {
					if(visiteds.contains(n)) continue;
					if(0<adjacency[nIdx][n]) {
						final NTNode child = nodes.get(n); 
						if(proceed.contains(child)) {
							final int rIdx = proceed.indexOf(child);
							proceed.remove(rIdx);
						}
						
						proceed.add(child);
					}
				}
			}
			
			final NTModel newModel = NTModel.singleModel(nodes, adjacency, modelNodes, threshold); 
			models.add(newModel);
			modelNodes.removeAll(modelNodes);
		}	
	}
	
	
	public void forceDirectedRound() {
		final double bound = _distBound * 1.5;
		Collections.sort(nodes);
								
		for(int p=0; p<nodes.size(); p++) {
			final NTNode node = nodes.get(p);
			if(!node.isActive() || toRemove.contains(node))
				continue;
			
			final ArrayList<NTNode> neighbor = NTUtil.kNeighbor(nodes, p, bound);			
			
			// line fit
			if(3<=neighbor.size()) {
				neighbor.add(node);
				
				final double[] reg = NTUtil.lsmEstimate(neighbor);
				if(reg[0]<1 && node.estimedRad(reg)<_tolerance) {
					node.fit(reg);
//					toFix.add(node);
				} else {
					for(NTNode nt : neighbor) {
						if(nt.isActive() && !node.equals(nt)) toRemove.add(nt);
					}
					node.merge(neighbor);
				}
			} else {
				toFix.add(node);
			}
		}

	}

	
	
	public static abstract class Listener {
		protected abstract void handle(Status status); 
	}

	public static enum Status {
		READY,
		ROUND_ITERATING,
		ROUND_COMPLETE,
		DONE,
		ERROR,
	}
	
	public static enum COLORFILTER {
		GRAY(0),
		RED(0),
		GREEN(8),
		BLUE(16)
		;
		final int shiftFrame;
		COLORFILTER(int shift) {
			this.shiftFrame = shift;
		}
		
		int filter(int digit) {
			return (digit>>shiftFrame)&0xFF;
		}
	}
	
}
