package lab.ibio.t4trace.workbench;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.eclipse.core.commands.Command;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.commands.NotEnabledException;
import org.eclipse.core.commands.NotHandledException;
import org.eclipse.core.commands.common.NotDefinedException;
import org.eclipse.equinox.app.IApplication;
import org.eclipse.equinox.app.IApplicationContext;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.ICommandService;

/**
 * This class controls all aspects of the application's execution
 */
public class Application implements IApplication {

	public static final int SINGLE_GRIDSIZE = 2;
	
	protected static HashMap<String, Object> _uiElements;
	protected static IWorkbench _workbench;
	protected static ICommandService _commandService;
	protected static Logger _logUnit = Logger.getAnonymousLogger();
	
	public static Shell shell() {
		if(_workbench == null)
			_workbench = PlatformUI.getWorkbench();
		return _workbench.getActiveWorkbenchWindow().getShell();
	}
	
	public static IWorkbenchWindow window() {
		if(_workbench == null)
			_workbench = PlatformUI.getWorkbench();
		return _workbench.getActiveWorkbenchWindow();
	}
	
	public static IWorkbenchPage activePage() {
		return window().getActivePage();
	}
	
	public static void __log(Level lv, String title, String message) {
		_logUnit.log(lv, String.format("%s: %s", title, message));
		final int swtLevelFlag;
		if(Level.SEVERE.equals(lv))
			swtLevelFlag = MessageDialog.ERROR;
		else if(Level.WARNING.equals(lv))
			swtLevelFlag = MessageDialog.WARNING;
		else 
			swtLevelFlag = MessageDialog.INFORMATION;
		
		MessageDialog.open(swtLevelFlag, shell(), title, message, SWT.SHEET);
	}
	
	public static void info(String title, String message) { __log(Level.INFO, title, message); } 
	public static void warning(String title, String message) { __log(Level.WARNING, title, message); }
	public static void error(Exception ex) {
		final StringBuffer buffer = new StringBuffer("\n");
		for(StackTraceElement st : ex.getStackTrace()) {
			buffer.append(String.format("%s:%d:%s >> %s\n", 
					st.getFileName(), st.getLineNumber(), st.getClassName(), st.getMethodName()));
		}
		__log(Level.SEVERE, ex.getMessage(), buffer.toString()); 
	}
	
	
//	public static ViewPart focusedView() {
//		
//	}
	
	
	public static IViewPart showView(String id, String secondaryId, int mode) {
		try {
//			for(ViewReference ref : activePage().getViewReferences()) {
//				ref.
//			}
			return activePage().showView(id, secondaryId, mode);
		} catch (PartInitException e) {
			e.printStackTrace();
			return null;
		}
	}
	public static IViewPart showView(String id) {
		return showView(id, null, IWorkbenchPage.VIEW_VISIBLE);
	}
	
	@SuppressWarnings("rawtypes")
	public static void runCommand(String cmdId, Object trigger, Map data) {
		if(_commandService==null) {
			if(_workbench == null)
				_workbench = PlatformUI.getWorkbench();
			_commandService = (ICommandService) _workbench.getService(ICommandService.class);
		}
		final Command cmd = _commandService.getCommand(cmdId);
		final ExecutionEvent event;
		if(data==null) {
			event = new ExecutionEvent();
		} else {
			event = new ExecutionEvent(cmd, data, trigger, null);
		}
		
		try {
			cmd.executeWithChecks(event);
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotDefinedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotEnabledException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotHandledException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	/* (non-Javadoc)
	 * @see org.eclipse.equinox.app.IApplication#start(org.eclipse.equinox.app.IApplicationContext)
	 */
	public Object start(IApplicationContext context) {
		NTPreference.initateDefault();
		
		// test
		Display display = PlatformUI.createDisplay();
		try {
			int returnCode = PlatformUI.createAndRunWorkbench(display, new ApplicationWorkbenchAdvisor());
			if (returnCode == PlatformUI.RETURN_RESTART) {
				return IApplication.EXIT_RESTART;
			}
			return IApplication.EXIT_OK;
		} catch(Exception ex) {
			error(ex);
		}
		finally {
			display.dispose();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.equinox.app.IApplication#stop()
	 */
	public void stop() {		
		if (!PlatformUI.isWorkbenchRunning())
			return;
		final IWorkbench workbench = PlatformUI.getWorkbench();
		final Display display = workbench.getDisplay();
		display.syncExec(new Runnable() {
			public void run() {
				if (!display.isDisposed())
					workbench.close();
			}
		});
	}
}
