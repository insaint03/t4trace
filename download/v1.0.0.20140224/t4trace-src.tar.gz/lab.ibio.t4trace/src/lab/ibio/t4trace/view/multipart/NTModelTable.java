package lab.ibio.t4trace.view.multipart;

import java.util.ArrayList;

import lab.ibio.t4trace.analytics.NTModel;
import lab.ibio.t4trace.analytics.NTProcess;
import lab.ibio.t4trace.plug.NTTabTable;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.TabFolder;

public class NTModelTable extends NTTabTable {
	
	
	private final ArrayList<Item> itemList;
	
	
	private static final String[] COLUMNS = new String[] {
		"File", "Soma", "Total len.", "Longest branch", "Polarity", "# pts", "# branches", "# terminals" 
	};
	
	public NTModelTable(TabFolder tabFolder) {
		super(tabFolder);
		
		this.itemList = new ArrayList<Item>();
		tableViewer.setInput(itemList);
	}
	
	public void clear() {
		itemList.removeAll(itemList);
		tableViewer.refresh();
	}
	
	public void appendItem(NTProcess process, NTModel model) {
		itemList.add(new Item(process, model));
	}
	
	public void refresh() {
		tableViewer.refresh();
		itemPane.getParent().redraw();
	}
	
	@Override
	protected String getTabTitle() {
		return "Models";
	}
	
	@Override
	protected String[] getColumnTitles() {
		return COLUMNS;
	}
	
	@Override
	protected int getColumnDefaultWidthAt(int idx) {
		return 64;
	}
	
	@Override
	protected IStructuredContentProvider getContentProvider() {
		return new IStructuredContentProvider() {
			private Item[] items = null;
			
			@Override
			public void dispose() { }

			@Override
			public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {
			}

			@Override
			public Object[] getElements(Object inputElement) {
				if(items==null || items.length!=itemList.size()) {
					items = itemList.toArray(new Item[itemList.size()]);
				}
				return items;
			}
		};
	}
	
	@Override
	protected ITableLabelProvider getLabelProvider() {
		return new ITableLabelProvider() {
//			HashMap<NTProcess, Image> imageMap = new HashMap<NTProcess, Image>();

			@Override
			public void addListener(ILabelProviderListener listener) {
			}

			@Override
			public void dispose() {
			}

			@Override
			public boolean isLabelProperty(Object element, String property) {
				
				return true;
			}

			@Override
			public void removeListener(ILabelProviderListener listener) {
			}
			
			@Override
			public Image getColumnImage(Object element, int columnIndex) {
				return null;
			}

			@Override
			public String getColumnText(Object element, int columnIndex) {
				if(element instanceof Item) {
					final Item item = (Item) element;
		
					switch(columnIndex) {
					case 0:
						return item.fin;
					case 1:
						return item.soma;
					case 2:
						return String.format("%.2f", item.totalLength);
					case 3:
						return String.format("%.2f", item.longest);
					case 4:
						return String.format("%.2f", item.polarity);
					case 5:
						return String.format("%d", item.totalPtsCnt);
					case 6:
						return String.format("%d", item.brancheCnt);
					case 7:
						return String.format("%d", item.terminalCnt);
					default:
						break;
					}
				}
				return null;
			}
		};	
	}
	
	private static class Item {
		final String fin;
		final String soma;
		final double totalLength;
		final double longest;
		final double polarity;
		final int totalPtsCnt;
		final int brancheCnt;
		final int terminalCnt;
		
		Item(NTProcess process, NTModel model) {
			
			this.fin = process.getInputFile().getName();
			this.soma = model.getSomaString();
			this.totalLength = model.getTotalLength();
			this.longest = model.getLongestBranch();
			this.polarity = model.getPolarity();
			this.totalPtsCnt = model.getPointCounts();
			this.brancheCnt = model.getBranchCounts();
			this.terminalCnt = model.getTerminalCounts();
		}
		
	}

}

