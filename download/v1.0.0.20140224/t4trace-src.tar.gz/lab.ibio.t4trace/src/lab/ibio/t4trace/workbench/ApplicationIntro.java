package lab.ibio.t4trace.workbench;

import org.eclipse.ui.splash.AbstractSplashHandler;

public class ApplicationIntro extends AbstractSplashHandler {

	public ApplicationIntro() {
		// TODO Auto-generated constructor stub
		System.out.println("Intro");
	}

}
