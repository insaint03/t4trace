package lab.ibio.t4trace.analytics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.GC;

public class NTModel implements Serializable {
	private static final long serialVersionUID = 6740385779579812654L;
	
	private double[][] distMap;
	private int[][] nextMap;
	private double totalLen;
	private double polarity;
	private final int threshold;
	
	private final NTNode[] points;
	private int seedIdx;
	private ArrayList<Integer> terminals;
	private ArrayList<Integer> branches;
	
	public static NTModel singleModel(ArrayList<NTNode> nodes, double[][] adjacency, ArrayList<Integer> nIndices, int threshold) {
		final NTModel model = new NTModel(nIndices.size(), threshold);
		for(int i=0; i<nIndices.size(); i++)
			model.points[i] = nodes.get(nIndices.get(i));
		
		// initialize
		model.fwShortestDistance(nodes, adjacency, nIndices);
		
		// classify nodes
		model.classifyTraces();
		
		// calculate values
		model.measurePolarity();
		
		return model;
	}
	
	private NTModel(int size, int thresh) {
		this.points = new NTNode[size];
		this.branches = new ArrayList<Integer>();
		this.terminals = new ArrayList<Integer>();
		this.threshold = thresh;
	}
	
	public int getDirectParentOf(int idx) {
		return nextMap[seedIdx][idx];
	}
	
	public NTNode getRoot() {
		return points[seedIdx];
	}
	
	public NTNode.Type getTypeOf(int iIdx) {
		if(iIdx == seedIdx)
			return NTNode.Type.Soma;
		else if(terminals.contains(iIdx))
			return NTNode.Type.Terminal;
		else if(branches.contains(iIdx))
			return NTNode.Type.Branch;
		else
			return NTNode.Type.Trunk;
		
	}
	
	
	public String getSomaString() {
		final NTNode soma = points[seedIdx];
		return String.format("%.1f (%d, %d)", soma.radius(threshold, false), soma.x(), soma.y());
	}
	
	public double getTotalLength() {
		return totalLen;
	}
	
	public double getLongestBranch() {
		if(0<=getFarthestTermIdx())
			return distMap[seedIdx][getFarthestTermIdx()];
		else return 0;
	}
	
	public double getPolarity() {
		// find farthest
		return polarity;
	}
	
	public int getPointCounts() {
		return points.length;
	}
	
	public int getBranchCounts() {
		return branches.size();
	}
	
	public NTNode[] getPoints() {
		return this.points;
	}
	
	public int getTerminalCounts() {
		return terminals.size();
	}
	
	public String textReport() {
		final StringBuffer buf = new StringBuffer();
		buf.append(String.format("> NUCLEOR(%d, %d) : %.2f px intensity \n", 
			points[seedIdx].x(), points[seedIdx].x(), Math.sqrt(points[seedIdx].mass())));
		
		if(3<points.length) {
			buf.append(String.format("  LENGTH TOTAL: %.2f \n", totalLen));
			buf.append(String.format("  # TERMINALS: %d \n", terminals.size()));
			buf.append(String.format("  # BRANCHING POINTS: %d \n", branches.size()));
			final int far = getFarthestTermIdx();
			buf.append(String.format("  LONGEST(%d, %d): %.2f \n", points[far].x(), points[far].y(), distMap[far][seedIdx]));
			buf.append(String.format("  AVERAGE INTENSITY: %.2f \n", averageIntensity()));
		} else {
			buf.append(" - insignificant \n");
		}
		buf.append(" \n");
		
		return buf.toString();
	}
	
	public double averageIntensity() {
		double sum = 0;
		if(1<points.length) {
			
			for(int i=0; i<points.length; i++) {
				if(i==seedIdx) continue;
				
				sum+=Math.sqrt(points[i].mass());
			}
			
			return sum/(points.length-1);
		}
		else {
			return Math.sqrt(points[seedIdx]._mass);
		}
	}
	
	public int getFarthestTermIdx() {
		int ret = -1;
		double len = 0;
		for(int idx : terminals) {
			if(len < distMap[idx][0]) {  
				ret = idx;
				len = distMap[idx][0];
			}
		}
		
		return ret;
	}
	
	public void drawImage(GC gc, Color seed, Color branch, Color line, int threshold, int compression) {
		gc.setForeground(line);
		
		final int[] visitingCnt = new int[points.length];
		for(int i=0; i<points.length; i++) {
			if(nextMap[i][seedIdx]<0) continue;
		
			final NTNode src = points[i];
			final NTNode trg = points[nextMap[i][seedIdx]];
			gc.drawLine(src.x()/compression, src.y()/compression, trg.x()/compression, trg.y()/compression);
			visitingCnt[nextMap[i][seedIdx]] += 1;
		}
		
		
		for(int i=points.length-1; 0<=i; i--) {
			final NTNode nt = points[i];
			final int rad = (int)Math.max(2/compression, (nt.radius(threshold, false)/compression));
			if(i==seedIdx) {
				gc.setBackground(seed);
			} else if(branches.contains(i)) {
				gc.setBackground(branch);
			} else if(terminals.contains(i)) {
				continue;
			} else {
				continue;
			}
			
			gc.fillOval(nt.x()/compression-rad, nt.y()/compression-rad, rad*2, rad*2);
		}
		
	}
	
	private double measurePolarity() {
		final int farthest = getFarthestTermIdx();
		if(farthest<0)
			return 0;
		
		final HashSet<Integer> path = new HashSet<Integer>();
		
		int pt = farthest;
		while(pt!=seedIdx) {
			path.add(pt);
			pt = nextMap[pt][seedIdx];
			
		}
		// find next, without overlapping path
		for(int idx : terminals) {
			
			int trail = idx;
			while(!path.contains(trail) && trail!=seedIdx &&(0<=trail && trail<points.length)) {
				trail = nextMap[trail][seedIdx];
			}
			
			if(trail==seedIdx) {
				final double fLen = distMap[farthest][seedIdx];
				final double nLen = distMap[idx][seedIdx];
				
				polarity = fLen / (nLen+fLen);
				break;
			}
		}
		
		return polarity;
		
		
	}

	private void classifyTraces() {
		// TODO: seed determinant
		this.seedIdx = 0;
		
		//
		final int[] visitingCnt = new int[points.length];
		Arrays.fill(visitingCnt, 0);
		visitingCnt[seedIdx] = 0;
		
		this.totalLen = 0;
		for(int i=0; i<points.length; i++) {
			if(i==seedIdx || nextMap[i][seedIdx]<0 || points.length<=nextMap[i][seedIdx]) continue;
			
			if(visitingCnt[nextMap[i][seedIdx]] <= 1) {
				totalLen += distMap[i][nextMap[i][seedIdx]];
			}
			
			visitingCnt[nextMap[i][seedIdx]] += 1;
		}
		
		// define branches
		for(int i=0; i<points.length; i++) {
			if(i==seedIdx) 
				continue;
			
			if(visitingCnt[i]==0) 
				terminals.add(i);
			else if(1<visitingCnt[i]) 
				branches.add(i);
		}
	}
	
	private void fwShortestDistance(ArrayList<NTNode> traces, double[][] adjacency, ArrayList<Integer> ns) {
		distMap = new double[ns.size()][ns.size()];
		nextMap = new int[ns.size()][ns.size()];
		
		for(int i=0; i<ns.size(); i++) 
			Arrays.fill(nextMap[i], -1);
		
		for(int i=0; i<ns.size();  i++) {
			for(int j=0; j<i; j++) {
				final double dValue = adjacency[ns.get(i)][ns.get(j)];
				if(0<dValue) {
					distMap[i][j] = dValue;
					distMap[j][i] = dValue;
					nextMap[i][j] = j;
					nextMap[j][i] = i;
				}
			}
		}
		
		for(int k=0; k<ns.size(); k++) {
			for(int i=0; i<ns.size(); i++) {
				for(int j=0; j<ns.size(); j++) {
					if(i==j || i==k || j==k) continue;
					
					if(0<distMap[i][k] && 0<distMap[k][j]) {
						final double dist = distMap[i][k] + distMap[k][j];
						if(distMap[i][j]<=0 || dist < distMap[i][j]) {
							distMap[i][j] = dist;
							nextMap[i][j] = k;
						}
					}
				}
			} 
		}
	}
}

