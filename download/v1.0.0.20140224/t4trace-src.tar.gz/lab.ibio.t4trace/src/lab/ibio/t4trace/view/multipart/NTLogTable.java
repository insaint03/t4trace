package lab.ibio.t4trace.view.multipart;

import java.util.ArrayList;
import java.util.HashMap;

import lab.ibio.t4trace.analytics.NTProcess;
import lab.ibio.t4trace.plug.NTTabTable;
import lab.ibio.t4trace.workbench.NTPreference;

import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.widgets.TabFolder;

public class NTLogTable extends NTTabTable {
	

	private final ArrayList<NTProcess> itemList;
	
	private static int ICON_LEN = 128;
	
	private static final String[] COLUMNS = new String[] {
		"", "File", "Thresh", "# models", "totalLen", "longest", "time (ms)", "init. # pts", "fin. # pts"
	};
	
	public NTLogTable(TabFolder tabFolder) {
		super(tabFolder);
		
		this.itemList = new ArrayList<NTProcess>();
		tableViewer.setInput(itemList);
	}
	
	public void clear() {
		itemList.removeAll(itemList);
		tableViewer.refresh();
	}
	
	public void appendItem(NTProcess proc) {
		itemList.add(proc);
	}
	
	public void refresh() {
		tableViewer.refresh();
		itemPane.getParent().redraw();
	}
	
	@Override
	protected String getTabTitle() {
		return "Summary";
	}
	
	@Override
	protected String[] getColumnTitles() {
		return COLUMNS;
	}
	
	@Override
	protected int getColumnDefaultWidthAt(int idx) {
		if(idx==0)
			return ICON_LEN+8;
		else
			return 64;
	}
	
	
	@Override
	protected IStructuredContentProvider getContentProvider() {
		return new IStructuredContentProvider() {
			private NTProcess[] items = null;
			
			@Override
			public void dispose() { }

			@Override
			public void inputChanged(Viewer viewer, Object oldInput, Object newInput) {	}

			@Override
			public Object[] getElements(Object inputElement) {
				if(items==null || items.length!=itemList.size()) {
					items = itemList.toArray(new NTProcess[itemList.size()]);
				}
				
				return items;
			}
		};
	}
	
	@Override
	protected ITableLabelProvider getLabelProvider() {
		// TODO Auto-generated method stub
		return new ITableLabelProvider() {
			HashMap<NTProcess, Image> imageMap = new HashMap<NTProcess, Image>();

			@Override
			public void addListener(ILabelProviderListener listener) {
			}

			@Override
			public void dispose() {
			}

			@Override
			public boolean isLabelProperty(Object element, String property) {
				return true;
			}

			@Override
			public void removeListener(ILabelProviderListener listener) {
			}
			
			@Override
			public Image getColumnImage(Object element, int columnIndex) {
				final Color seedColor = NTPreference.getColorValue(_display, NTPreference.MULTI_COLOR_SEED);
				final Color ptColor = NTPreference.getColorValue(_display, NTPreference.MULTI_COLOR_BRANCH);
//				final Color brColor = _display.getSystemColor(SWT.COLOR_CYAN);
				final Color baseColor = NTPreference.getColorValue(_display, NTPreference.MULTI_COLOR_LINE);
				if(columnIndex==0) {
					final NTProcess process = (NTProcess)element;
					if(!imageMap.containsKey(process)) {
//						final Image icon = new Image(_display, ICON_LEN, ICON_LEN);
						final ImageData _idata = process.getBaseImageData();
//						final Image bgImg = new Image(_display, _idata);
						final int compress = Math.max(_idata.width, _idata.height)/ICON_LEN;
						final Image modelImg = process.drawModels(_display, seedColor, ptColor, baseColor, compress);
											
						imageMap.put(process, modelImg);
					}
					
					return imageMap.get(process);
				}
				return null;
			}

			@Override
			public String getColumnText(Object element, int columnIndex) {
				final NTProcess proc = (NTProcess) element;

				switch(columnIndex) {
				case 1:
					return proc.getInputFile().getName();
				case 2:
					return String.format("%d<", proc.getThreashold());
				case 3:
					return String.format("%d", proc.getModels().size());
				case 4:
					return String.format("%.2f", proc.getModelTotalLen());
				case 5:
					return String.format("%.2f", proc.getLongestModel());
				case 6:
					return String.format("%d", proc.getTimeCost());
				case 7:
					return String.format("%d", proc.getInitialPointCount());
				case 8:
					return String.format("%d", proc.getFinalPointCount());
				default:
					return null;
				}
				
			}
		};
	}

}

