package lab.ibio.t4trace.view;

import lab.ibio.t4trace.plug.NTView;

import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.widgets.Composite;

public class NTTableView extends NTView {
	/**
	 * descriptor
	 */
	public static final String ID = "lab.ibio.t4trace.view.table";
	public static final String[] extensions = new String[]{"csv", "tsv"};
	public NTTableView() {
		super(ID, extensions);
	}
	
	TableViewer tableView;
	
	@Override
	protected String windowTitle() {
		return String.format("Table Viewer> %s",  _file.getAbsolutePath());
	}
	
	@Override
	public void _createControl(Composite parent) {
		this.tableView = new TableViewer(parent);
	}

	@Override
	public void setFocus() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void open() {
		
	}
	
}
