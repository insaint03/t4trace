package lab.ibio.t4trace.handler;

import java.util.HashMap;

import lab.ibio.t4trace.workbench.Application;

import org.eclipse.jface.action.Action;


public class NTAction extends Action {
	
	public static final NTAction FILE_WORKSPACE = new NTAction(ActionWorkspace.ID, "set &Workspace...");
//	public static final NTAction FILE_SAVEDATA = new NTAction(ActionSave.ID, "&Save Current Data");
	
	private static final HashMap<String, Object> __parameters = new HashMap<String, Object>();
	
	
	public NTAction(String id, String label) {
		setId(id);
		setText(label);
	}
	
	protected static void initParameters() {
		__parameters.clear();
	}
	
	protected static void setParameter(String key, Object value) {
		__parameters.put(key, value);
	}
	
//	protected static Map parameters() {
//		return __parameters;
//	}
	
	@Override
	public void run() {
		Application.runCommand(getId(), null, null);
	}

}
