package lab.ibio.t4trace.plug;

import lab.ibio.t4trace.analytics.NTUtil;

import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.FileDialog;
import org.eclipse.swt.widgets.Menu;
import org.eclipse.swt.widgets.MenuItem;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.TableColumn;

public abstract class NTTabTable {
	
	protected final Display _display;
	
	protected TabItem itemPane;
	protected TableViewer tableViewer;
	protected Menu tablePopup;
	
	protected String[] _columns;
	
	protected abstract String getTabTitle();
	protected abstract String[] getColumnTitles();
	protected abstract int getColumnDefaultWidthAt(int idx);
	protected abstract IStructuredContentProvider getContentProvider();
	protected abstract ITableLabelProvider getLabelProvider();
	
	public NTTabTable(final TabFolder tabFolder) {
		this._display = tabFolder.getDisplay();
		this.itemPane = new TabItem(tabFolder, SWT.NONE);
		this.itemPane.setText(getTabTitle());
		
		final Composite container = new Composite(tabFolder, SWT.NONE);
		container.setLayout(new FillLayout());
		
		this.tableViewer = new TableViewer(container);
		//
		this._columns = getColumnTitles();
		tableViewer.setColumnProperties(_columns);
		tableViewer.setContentProvider(getContentProvider());
		tableViewer.setLabelProvider(getLabelProvider());
		
		for(int i=0; i<_columns.length; i++) {
			_addTableColumn(_columns[i], true, getColumnDefaultWidthAt(i));
		}
		
		tableViewer.getTable().setHeaderVisible(true);
		
		itemPane.setControl(container);
		
		tablePopup = new Menu(tableViewer.getTable());
		tableViewer.getTable().setMenu(tablePopup);
		
		addPopupMenu("Save current as Text(.txt)", SWT.PUSH, new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				final FileDialog dlg = new FileDialog(tabFolder.getShell(), SWT.SAVE);
				dlg.setFilterExtensions(new String[]{"*.txt"});
				String selected = dlg.open();
				if(selected.toLowerCase().endsWith("."+ NTUtil.DEFAULT_TABLE_EXTENSION))
					selected = selected.substring(0, selected.lastIndexOf('.'));
				
				if(selected!=null) {
					saveAsText(selected);
				}
					
			}
		});
	}
	
	public boolean customTable() {
		return false;
	}
	
	protected void _addTableColumn(String title, boolean resizable, int defaultWidth) {
		final TableColumn column = new TableColumn(tableViewer.getTable(), SWT.NONE);
		column.setText(title);
		column.setResizable(resizable);
		column.setWidth(defaultWidth);
	}
	
	
	protected void addPopupMenu(String title, int swt, SelectionListener listener) {
		final MenuItem item = new MenuItem(tablePopup, swt);
		item.setText(title);
		item.addSelectionListener(listener);
	}
	
	public void refresh() {
		if(!customTable()) {
			tableViewer.refresh();
			itemPane.getParent().redraw();
		}
	}
	
	public void saveAsText(String name) {
		NTUtil.saveAs(tableViewer.getTable(), name, NTUtil.DEFAULT_TABLE_EXTENSION);
	}
}
