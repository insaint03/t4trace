package lab.ibio.t4trace.view.multipart;

import java.util.ArrayList;

import lab.ibio.t4trace.analytics.NTModel;
import lab.ibio.t4trace.analytics.NTNode;
import lab.ibio.t4trace.analytics.NTProcess;

import org.eclipse.swt.SWT;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.TabItem;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class NTNodeTable {
	
	private Table table;
	
	
	private final StringBuffer textBuffer;
	
	private static final String[] COLUMNS = {
		"File", "node_id", "root_id", "direct_parent_id", "Position", "Radius", "Type", 
	};
	
	public NTNodeTable(StringBuffer buffer) {
		this.textBuffer = buffer;
	}

	public NTNodeTable(TabFolder tabFolder) {
		final TabItem item = new TabItem(tabFolder, SWT.NONE);
		item.setText("Nodes");
		final Composite container = new Composite(tabFolder, SWT.NONE);
		container.setLayout(new GridLayout(1, true));
		
		this.table = new Table(container, SWT.NONE);
		table.setHeaderVisible(true);
		
		for(int i=0; i<COLUMNS.length; i++) {
			final TableColumn column = new TableColumn(table, SWT.NONE);
			column.setText(COLUMNS[i]);
			column.setWidth(64);
			column.setResizable(true);
		}
		
		//
		item.setControl(container);
		table.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		textBuffer = null;
	}
	
	public StringBuffer getCustomBuffer() {
		return this.textBuffer;
	}

	public void addInput(NTProcess process) {  
		final String fileName = process.getInputFilename(false);
		final ArrayList<NTNode> procNodes = process.getNodes();
		
		for(final NTModel model : process.getModels()) {
			final NTNode root = model.getRoot();
			final int rIdx = procNodes.indexOf(root)+1;
			
			final NTNode[] points = model.getPoints();
			for(int i=0; i<points.length; i++) {
				final int nIdx = procNodes.indexOf(points[i])+1;
				final int pIdx;
				if(points[i].equals(root))
					pIdx = rIdx;
				else
					pIdx = model.getDirectParentOf(i)+1;
				
				if(textBuffer==null) {
					final TableItem _item = new TableItem(table, SWT.NONE);
					_item.setText(0, fileName);
					_item.setText(1, Integer.toString(nIdx));
					_item.setText(2, Integer.toString(rIdx));
					_item.setText(3, Integer.toString(pIdx));
					_item.setText(4, String.format("%.2f,%.2f", points[i]._x(), points[i]._y()));
					_item.setText(5, String.format("%.2f", points[i].radius(0, false)));
					_item.setText(6, model.getTypeOf(i).name());
				}
				else {
					textBuffer.append(String.format("%s\t%d\t%d\t%d\t%.2f,%.2f\t%.2f\t%s\n",
						fileName, 
						nIdx, rIdx, pIdx, 
						points[i]._x(), points[i]._y(), points[i].radius(0, false), 
						model.getTypeOf(i).name()));
				}
					
				
			}
			
		}
	}
	
	public void addCustomProcess(NTProcess process) {
	
	}

	protected int getColumnDefaultWidthAt(int idx) {
		if(idx<=0)
			return 128;
		else if(idx<=2)
			return 32;
		else
			return 64;
	}

}
