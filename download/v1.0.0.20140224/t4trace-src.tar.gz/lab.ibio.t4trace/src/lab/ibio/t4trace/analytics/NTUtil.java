package lab.ibio.t4trace.analytics;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import java.util.logging.Level;

import lab.ibio.t4trace.workbench.Application;

import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.graphics.ImageData;
import org.eclipse.swt.graphics.ImageLoader;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.widgets.TableItem;

public class NTUtil {
	
	public static final String DEFAULT_IMAGE_EXTENSION = "png";
	public static final String DEFAULT_TABLE_EXTENSION = "txt";
	
	public static void saveAs(Object obj, String fpath, String extension) {
		try {
			if(obj instanceof Image) {
				final Image image = (Image) obj;
				saveAsImageDelegate(fpath, image, extension);
			} else if(obj instanceof Table) {
				final Table table = (Table) obj;
				saveAsTableTextDelegate(fpath, table, extension);
			} else if(obj instanceof StringBuffer) {
				saveAsTextDelegate(fpath, ((StringBuffer)obj).toString());
			}
		} catch(IOException ex) {
			Application.__log(Level.WARNING, "File save error", ex.getMessage());
		}
		
	}
	
	public static int autoThresholding(int[][] frame) {
		final int[] pxCounts = new int[0x100];
		Arrays.fill(pxCounts, 0);
		
		for(int y=0; y<frame.length; y++) {
			for(int x=0; x<frame[y].length; x++) {
				if(0<frame[y][x] && frame[y][x]<pxCounts.length) {
					pxCounts[frame[y][x]] += 1;
				}
			}
		}
		
		return fuzzyThreshold(pxCounts);
	}
	
	
	public static int fuzzyThreshold(int[] counts) {
		return fuzzyThreshold(null, counts);
	}
	
	public static int fuzzyThreshold(int[] values, int[] counts) {
		final HashSet<Integer> visiteds = new HashSet<Integer>();
		
		
		int threshold = -1;
		if(values!=null) {
			for(int i=0; i<values.length; i++)
				threshold += values[i];
			
			threshold /= values.length;
		} else {
			threshold = counts.length/2;
		}
		
		while(!visiteds.contains(threshold)) {
			visiteds.add(threshold);
			
			float lowerMean=0, upperMean=0;
			int lowerCnt = 0, upperCnt = 0;
			
			for(int i=0; i<counts.length; i++) {
				final int value = values!=null?values[i]:i;
				final int count = counts[i];
				
//				if(value==0) continue;
				
				if(i<=threshold) {
					lowerMean += value*count;
					lowerCnt += count;
				}
				else {
					upperMean += value*count;
					upperCnt += count;
				}
			}
			
			threshold = (int)Math.round((lowerMean/(double)lowerCnt + upperMean/(double)upperCnt)/2);
			// avoid 0 threshold
			if(threshold==0) {
				for(int i=1; !visiteds.contains(i); i++) {
					threshold = i;
//					break;
				}					
			}
		}
		
		return threshold;
	}
	
	public static double[][] connectivity(int[][] pixels, ArrayList<NTNode> nodes, int threshold, int boundary) {
		final int radix = pixels.length;
		final int[][] proc = new int[pixels.length][];
		final int[] boundaryVals = new int[nodes.size()];
		
		for(int y=0; y<pixels.length; y++) {
			proc[y] = new int[pixels[y].length];
		}
		
		
		// initialize extending space
		for(int i=0; i<nodes.size(); i++) {
			final NTNode node = nodes.get(i);
			// at least the point
			proc[node.y()][node.x()] = i+1;
			
			final int rad = Math.max(1, (int)node.radius(threshold, false));
			int cnt = 0;
			double aveIntensity = 0.0;
			for(int dy=-rad; dy<=rad; dy++) {
				for(int dx=-rad; dx<=rad; dx++) {
					final int px = node.x()+dx;
					final int py = node.y()+dy;
					
					if(inBound(proc, py, px) && (1<pixels[py][px])) {
						// 1 index
						proc[py][px] = i+1;
						aveIntensity += pixels[py][px];
						cnt += 1;
					}
				}
			}
			
			boundaryVals[i] = Math.max(boundary, (int)(aveIntensity/(2*cnt)));
		}
		
		final HashMap<Long, Integer> convertMap = new HashMap<Long, Integer>();
		while(true) {
			convertMap.clear();
			
			for(int y=0; y<proc.length; y++) {
				for(int x=0; x<proc.length; x++) {
					if(0<proc[y][x] && 0<pixels[y][x]) {
						for(int dx=-1; dx<=1; dx++) {
							for(int dy=-1; dy<=1; dy++) {
								if(inBound(proc, y+dy, x+dx) && proc[y+dy][x+dx]==0 
								&& (boundaryVals[proc[y][x]-1]<=pixels[y+dy][x+dx])) {
									final long idx = (x+dx)*(long)radix + (y+dy); 
									
									if(convertMap.containsKey(idx)) {
										continue;
									} else {
										convertMap.put(idx, proc[y][x]);
									}
								}
							}
						}
					}
				}
			}
			
			if(convertMap.isEmpty()) {
				break;
			}
				
			for(Entry<Long, Integer> entry : convertMap.entrySet()) {
				final int x = (int)(entry.getKey()/radix);
				final int y = (int)(entry.getKey()%radix);
				proc[y][x] = entry.getValue();
			}
		}
		
		// final confirm
		final double[][] adj = new double[nodes.size()][nodes.size()];
		for(int y=0; y<proc.length; y++) {
			for(int x=0; x<proc[y].length; x++) {
				if(0<proc[y][x]) {
					for(int dx=-1; dx<=1; dx++) {
						for(int dy=-1; dy<=1; dy++) {
							if(inBound(proc, y, x) && inBound(proc, y+dy, x+dx)
							&& 0<proc[y+dy][x+dx] && proc[y+dy][x+dx]!=proc[y][x]) {
								final int i = proc[y][x] -1;
								final int j = proc[y+dy][x+dx] -1;
								
								final double dist = nodes.get(i).distance(nodes.get(j));
								adj[i][j] = dist;
								adj[j][i] = dist;								
							}
						}
					}
				}
			}
		}
		return adj;
	}
	
	@Deprecated
	public static int[][] extending(int[][] rawPixels, int[][] procPixels, int threshold) {
//		final int radix = frame.width();
		final int radix = Math.min(rawPixels.length, procPixels.length);
		final HashSet<Long> visited = new HashSet<Long>();
		final ArrayList<Long> stack = new ArrayList<Long>();
		final int _bound = Math.max(2, threshold/32);
		final int _thresh = Math.max(32, threshold/2);
		
		// init partition - with astar
		for(int y=0; y<procPixels.length && y<rawPixels.length; y++) {
			for(int x=0; x<procPixels[y].length && x<rawPixels[y].length; x++) {
				if(1<procPixels[y][x]) {
					final long idxCode = x*radix + y;
					if(visited.contains(idxCode)) continue;
					
					stack.clear();
					
					stack.add(idxCode);
					
					while(!stack.isEmpty()) {
						final long pop = stack.remove(0);
						final int px = (int)pop/radix;
						final int py = (int)pop%radix;
//						final int ptValue = rawPixels[py][px];
						visited.add(pop);

						procPixels[py][px] = rawPixels[py][px];
						
						for(int dx=-1; dx<=1; dx++) {
							for(int dy= -1; dy<=1; dy++) {
								if(dx==0 && dy==0) continue;
								
								final long next = pop + (dx*radix) + dy;
								if(NTUtil.inBound(procPixels, py+dy, px+dx) && procPixels[py+dy][px+dx]==0 
								&& NTUtil.inBound(rawPixels, py+dy, px+dx) && _bound<rawPixels[py+dy][px+dx]
								&& Math.abs(rawPixels[py+dy][px+dx]-rawPixels[py][px])<=_thresh
								&& !visited.contains(next) && !stack.contains(next)) {
									stack.add(next);
								}
							}
						}
					}
				}
			}
		}
		
		return procPixels;
	}
	
	public static boolean inBound(int[][] pixels, int y, int x) {
		return 0<=y && y<pixels.length && 0<=x && x<pixels[y].length;
	}
		
	public static final double[] lsmEstimate(ArrayList<NTNode> neighbors) {
		double sx = 0;
		double sxx = 0;
		double sy = 0;
		double syy = 0;
		double sxy = 0;
		
		double minX=-1, maxX=-1;
		double minY=-1, maxY=-1;
		
		for(NTNode t : neighbors) {
			sx += t._x();
			sxx += t._x()*t._x();
			sy += t._y();
			syy += t._y()*t._y();
			sxy += t._x()*t._y();
			
			if(minX<0 || t._x()<minX) minX = t._x();
			if(maxX<0 || maxX<t._x()) maxX = t._x();
			if(minY<0 || t._y()<minY) minY = t._y();
			if(maxY<0 || maxY<t._y()) maxY = t._y();
		}
							
		final double detX = neighbors.size()*sxx - sx*sx;
		final double b1X = (sy*sxx - sx*sxy)/detX;
		final double b2X = (-sx*sy + neighbors.size()*sxy)/detX;
		
		final double detY = neighbors.size()*syy - sy*sy;
		final double b1Y = (sx*syy - sy*sxy)/detY;
		final double b2Y = (-sy*sx + neighbors.size()*sxy)/detY;
		double retX=0.0, retY = 0.0;
		for(NTNode t : neighbors) {
			final double eX= t._x()*b2X + b1X - t._y();
			final double eY= t._y()*b2Y + b1Y - t._x();
			retX += eX*eX;
			retY += eY*eY;
		}
		
		retX = Math.sqrt(retX);
		retY = Math.sqrt(retY);
		
		if(retX<=retY) {
			return new double[]{retX, b1X, b2X, detX, minX, minX*b2X+b1X, maxX, maxX*b2X+b1X, 1.0};
		}
		else { 
			return new double[]{retY, b1Y, b2Y, detY, minY*b2Y+b1Y, minY, maxY*b2Y+b1Y, maxY, -1.0};
		}
	}
	
	private static final ArrayList<NTNode> _neighbors = new ArrayList<NTNode>();
	public static final ArrayList<NTNode> kNeighbor(ArrayList<NTNode> traces, int seedIdx, double distBound) {
		// proximity 
		final NTNode src = traces.get(seedIdx);
		
		_neighbors.clear();
		
		for(int q=0; q<traces.size(); q++) {
			if(seedIdx==q || !traces.get(q).isActive()) continue;
		
			if(src.distance(traces.get(q))<distBound) {
				_neighbors.add(traces.get(q));
			}
		}
		
		
		return _neighbors;
	} 
	
	
	private static void saveAsImageDelegate(String path, Image image, String extension) throws IOException {
		final int format;
		switch(extension.toUpperCase()) {
		case "BMP":
			format = SWT.IMAGE_BMP; break;
		case "GIF":
			format = SWT.IMAGE_GIF; break;
		case "JPG":
		case "JPEG":
			format = SWT.IMAGE_JPEG; break;
		case "PNG":
			format = SWT.IMAGE_PNG; break;
		case "TIF":
		case "TIFF":
		default:
			format = SWT.IMAGE_TIFF; break;
		}
		
		final ImageLoader loader = new ImageLoader();
		loader.data = new ImageData[]{image.getImageData()};
		loader.save(String.format("%s.%s", path, extension), format);
	}
	
	private static void saveAsTableTextDelegate(String path, Table table, String extension)  throws IOException {
		final String itemDelimiter = "\n";
		final String columnDelimiter;
		
		switch(extension.toUpperCase()) {
		case "CSV":
			columnDelimiter = ","; break;
		case "TSV":
		default:
			columnDelimiter = "\t"; break;
		}
		
		final FileWriter fw = new FileWriter(String.format("%s.%s", path, extension));
		for(TableColumn column : table.getColumns()) {
			fw.write(column.getText());
			fw.write(columnDelimiter);
		}
		fw.write(itemDelimiter);
		 
		for(TableItem item: table.getItems()) {
			for(int i=0; i<table.getColumnCount(); i++) {
				fw.write(item.getText(i));
				fw.write(columnDelimiter);
			}
			fw.write(itemDelimiter);
		}
		
		fw.close();
	}
	
	private static void saveAsTextDelegate(String fpath, String text) throws IOException {
		final FileWriter fw = new FileWriter(fpath);
		fw.write(text);
		fw.close();
	}
	
}




