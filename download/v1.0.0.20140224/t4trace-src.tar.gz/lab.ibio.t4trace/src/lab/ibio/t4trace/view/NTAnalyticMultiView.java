package lab.ibio.t4trace.view;

import java.io.File;
import java.util.ArrayList;
import java.util.TreeMap;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import lab.ibio.t4trace.analytics.NTModel;
import lab.ibio.t4trace.analytics.NTProcess;
import lab.ibio.t4trace.analytics.NTProcess.COLORFILTER;
import lab.ibio.t4trace.analytics.NTUtil;
import lab.ibio.t4trace.plug.NTView;
import lab.ibio.t4trace.view.multipart.NTLogTable;
import lab.ibio.t4trace.view.multipart.NTModelTable;
import lab.ibio.t4trace.view.multipart.NTNodeTable;
import lab.ibio.t4trace.workbench.Application;
import lab.ibio.t4trace.workbench.NTPreference;

import org.eclipse.jface.viewers.IContentProvider;
import org.eclipse.jface.viewers.ILabelProviderListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITableLabelProvider;
import org.eclipse.jface.viewers.TableViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.jface.viewers.ViewerFilter;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.SashForm;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Color;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.DirectoryDialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.ProgressBar;
import org.eclipse.swt.widgets.Scale;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.TabFolder;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableItem;
import org.eclipse.swt.widgets.Text;


public class NTAnalyticMultiView extends NTView {
	
	public static final String ID = "lab.ibio.t4trace.view.multi";
	public static final String[] extensions = new String[]{NTView.HASHKEY_DIR};
	
	private static Color COLOR_SEED = null;
	private static Color COLOR_BRANCH = null;
	private static Color COLOR_LINE = null;
	
	private void initColors(Display disp) {
		final Display _d = Display.getCurrent();
		if(COLOR_SEED==null || !_d.equals(COLOR_SEED.getDevice()))
			COLOR_SEED = NTPreference.getColorValue(_d, NTPreference.MULTI_COLOR_SEED);
		if(COLOR_BRANCH==null || !_d.equals(COLOR_BRANCH.getDevice()))
			COLOR_BRANCH = NTPreference.getColorValue(_d, NTPreference.MULTI_COLOR_BRANCH);
		if(COLOR_LINE==null || !_d.equals(COLOR_LINE.getDevice()))
			COLOR_LINE = NTPreference.getColorValue(_d, NTPreference.MULTI_COLOR_LINE);
	}
	
	public NTAnalyticMultiView() {
		super(ID, extensions);
	}
	
	private TabFolder tabFolder;
	private Button filterModeBtn;
	private Text filterText;
	private TableViewer listTable;
	private Button selectAllBtn;
	
	private Scale gridScale;
	private Combo filterCombo;
	private Button processBtn;
	private Button fileSaveCnt;
	private ProgressBar procBar;
	private Label procLabel;
	
	private NTLogTable logTable;
	private NTModelTable modelTable;
	
	@Override
	protected void _createControl(Composite parent) {
		initColors(parent.getDisplay());
		
		final SashForm sash = new SashForm(parent, SWT.HORIZONTAL);
		tabFolder = new TabFolder(sash, SWT.BOTTOM);
		tabFolder.setLayoutData(new FillLayout());
		final Composite cntrWrapper = new Composite(sash, SWT.BORDER);
		cntrWrapper.setLayout(new GridLayout(1, true));
		
		// input group
		final Group inputGroup = new Group(cntrWrapper, SWT.NONE);
		inputGroup.setText("Input");
		inputGroup.setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true));
		inputGroup.setLayout(new GridLayout(2, false));
		
		createInputGroup(inputGroup);

		// Control group checkbox
		final Group procGroup = new Group(cntrWrapper, SWT.NONE);
		procGroup.setText("Process");
		final GridData procGroup_gd = new GridData(SWT.FILL, SWT.FILL, true, false);
		procGroup_gd.heightHint = 260;
		procGroup.setLayoutData(procGroup_gd);
		procGroup.setLayout(new GridLayout(4, true));
		
		createProcessGroup(procGroup);
		
		sash.setWeights(new int[]{6, 4});
		
		logTable = new NTLogTable(tabFolder);
		modelTable = new NTModelTable(tabFolder);
	}
	
	protected void createInputGroup(Group inputGroup) {
		filterModeBtn = new Button(inputGroup, SWT.TOGGLE);
		filterModeBtn.setSelection(false);
		filterModeBtn.setText("Include");
		filterModeBtn.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false));
		filterModeBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(filterModeBtn.getSelection()) {
					filterModeBtn.setText("Exclude");
				} else {
					filterModeBtn.setText("Include");
				}
				
				listTable.refresh();
			}
		});
		
		filterText = new Text(inputGroup, SWT.BORDER);
		filterText.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false));
		filterText.addModifyListener(new ModifyListener() {
			@Override
			public void modifyText(ModifyEvent e) {
				final Display disp = filterText.getDisplay();
				final String filterStr = filterText.getText();
				
				filterText.setBackground(disp.getSystemColor(SWT.COLOR_WIDGET_HIGHLIGHT_SHADOW));
				if(filterStr==null || filterStr.length()<=0) {
					filterText.setData(null);
				} else {
					try {
						filterText.setData(Pattern.compile(filterStr));
					} catch(PatternSyntaxException ex) {
						filterText.setBackground(disp.getSystemColor(SWT.COLOR_WIDGET_LIGHT_SHADOW));
					}
				}
				
				listTable.refresh();
			}
		});
		
		listTable = new TableViewer(inputGroup, SWT.MULTI | SWT.CHECK);
		listTable.getTable().setLayoutData(new GridData(SWT.FILL, SWT.FILL, true, true, 2, 1));
		
		selectAllBtn = new Button(inputGroup, SWT.CHECK);
		selectAllBtn.setText("select All");
		selectAllBtn.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				final Table table = listTable.getTable();
				for(TableItem item : table.getItems()) {
					item.setChecked(selectAllBtn.getSelection());
				}
			}
		});
	}
	
	protected void createProcessGroup(Group procGroup) {
		final Label filterLabel = new Label(procGroup, SWT.NONE);
		filterLabel.setText("Color Filter");
		filterLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 2, 1));
		
		filterCombo = new Combo(procGroup, SWT.READ_ONLY);
		filterCombo.setText(" -- select process");
		final NTProcess.COLORFILTER[] filterValues = NTProcess.COLORFILTER.values(); 
		for(COLORFILTER filter : filterValues) {
			filterCombo.add(filter.name());
		}
		filterCombo.select(0);
		filterCombo.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		
		final Label gridLevel = new Label(procGroup, SWT.NONE);
		gridLevel.setLayoutData(new GridData(SWT.LEFT, SWT.CENTER, false, false, 2, 1));
		
		gridScale = new Scale(procGroup, SWT.NONE);
		gridScale.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		gridScale.setMinimum(0);
		gridScale.setMaximum(7);
		gridScale.setIncrement(1);
		gridScale.setSelection(1);
		gridScale.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				final int size = (int)Math.pow(2, gridScale.getSelection());
				gridScale.setToolTipText(Integer.toString(size));
				
				gridLevel.setText(String.format("Grid Size (%d)", size));
			}
		});
		gridLevel.setText(String.format("Grid Size (%d)", (int)Math.pow(2, gridScale.getSelection())));
		
		fileSaveCnt = new Button(procGroup, SWT.CHECK);
		fileSaveCnt.setText("FILEs TO: ");
		fileSaveCnt.setSelection(false);
		fileSaveCnt.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 2, 1));
		fileSaveCnt.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(fileSaveCnt.getSelection()) {
					// final 
					final DirectoryDialog dlg = new DirectoryDialog(fileSaveCnt.getShell());
					dlg.setText("To Save");
					dlg.setMessage("Select Directory to save images and tsv table data");
					
					final String ret = dlg.open();
					if(ret!=null) {
						final File folder = new File(ret);
						if(folder.isDirectory() && folder.canWrite()) {
							fileSaveCnt.setData(folder);
							fileSaveCnt.setText(String.format("FILEs to : %s", folder.getName()));
						}
					}
					if(fileSaveCnt.getData()==null){
						fileSaveCnt.setSelection(false);
					}
				} else {
					fileSaveCnt.setData(null);
					fileSaveCnt.setText("FILEs TO: ");
				}
			}
			
			@Override
			public void widgetDefaultSelected(SelectionEvent e) {
				widgetSelected(e);
			}
		});
		
		
				
		procBar = new ProgressBar(procGroup, SWT.NONE);
		procBar.setSelection(0);
		procBar.setEnabled(false);
		procBar.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 3, 1));
		//
		processBtn = new Button(procGroup, SWT.TOGGLE);
		processBtn.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, false, false, 1, 1));
		
		procLabel = new Label(procGroup, SWT.NONE);
		procLabel.setLayoutData(new GridData(SWT.FILL, SWT.CENTER, true, false, 4, 2));
		
		
		processBtn.setText("START");
		processBtn.addSelectionListener(runAdapter);
	}
	
	@Override
	protected String windowTitle() 
	{
		return String.format("T4Trace Multi> %s",  _file.getAbsolutePath());
	}

	@Override
	protected void open() {
		// create summary
//		final TabItem summaryPane = new TabItem(tabFolder, SWT.NONE);
//		summaryPane.setText("Summary");
		
		listTable.getTable().setHeaderVisible(true);
		listTable.getTable().setLinesVisible(true);
		listTable.setContentProvider(contentProvider);
		listTable.setLabelProvider(labelProvider);
		listTable.addFilter(patternFilter);
		listTable.setInput(_file);

		
		setPartName(String.format("MULTI> %s", _file.getName()));
		setTitleToolTip(_file.getAbsolutePath());
	}

	@Override
	public void setFocus() {
		final Shell sh = Application.shell();
		sh.setDefaultButton(processBtn);
	}	
	
	private IContentProvider contentProvider = new IStructuredContentProvider() {
		@Override
		public void inputChanged(Viewer viewer, Object oldInput, Object newInput) { }
		@Override
		public void dispose() {	}
		
		@Override
		public Object[] getElements(Object inputElement) {
			if(inputElement instanceof File) {
				final File fin = (File)inputElement;
				
				if(fin.isDirectory()) {
					final ArrayList<File> ret = new ArrayList<File>();
					for(File cf : fin.listFiles()) {
						if(!cf.isDirectory())
							ret.add(cf);
					}
					return ret.toArray(new File[ret.size()]);
				}
			}
			return null;
		}
	};
	
	private SelectionAdapter runAdapter = new SelectionAdapter() { 
		int pointer = -1;
		final ArrayList<File> pstack = new ArrayList<File>();
//		final ArrayList<NTProcess> completeds = new ArrayList<NTProcess>();
	
		@Override
		public void widgetSelected(SelectionEvent e) {
			processBtn.setText("RUNNING...");
			processBtn.setEnabled(false);
			
			pstack.removeAll(pstack);
//			final Display disp = Display.getCurrent();
			final int gridSize = (int)Math.pow(2, gridScale.getSelection());
			final COLORFILTER colorFilter 
			= 0<filterCombo.getSelectionIndex()?COLORFILTER.valueOf(filterCombo.getText()):COLORFILTER.GRAY;
			
			for(TableItem item : listTable.getTable().getItems()) {
				if(item.getChecked()) {
					final File fin = (File) item.getData();
					pstack.add(fin);
					procLabel.setText("Loading......");
					try {
						Thread.sleep(0);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
				}
			}
			
			
			// update interfaces
			procBar.setEnabled(true);
			procBar.setMaximum(pstack.size());
			procBar.setSelection(0);
			procLabel.setText("Process Start:");
			
			final TreeMap<Integer, NTProcess> resultMap = new TreeMap<Integer, NTProcess>();
			
			final Thread processThread = new Thread(new Runnable(){
				@Override
				public void run() {
					for(pointer=0; pointer<pstack.size(); pointer++) {
						try {
							final NTProcess process = new NTProcess(pstack.get(pointer), gridSize, colorFilter);
							process.run(0);
							resultMap.put(pointer, process);
							
							Thread.sleep(0);
							
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			});
			
			processThread.start();
			
			Display.getCurrent().syncExec(new Runnable() {
				int from = 0;
				public void run() {
					
					synchronized (pstack) {
						logTable.clear();
						modelTable.clear();
						final NTNodeTable nodeTable = new NTNodeTable(new StringBuffer());
						
						initColors(Display.getCurrent());
						
						// if file save
						String toFolder = null;
						if(fileSaveCnt.getData() instanceof File) {
							toFolder = ((File)fileSaveCnt.getData()).getAbsolutePath();
							if(!toFolder.endsWith("/"))
								toFolder += "/";
						}
						
						int pstackSize = procBar.getMaximum();
						
						while(processThread.isAlive() || !resultMap.isEmpty()) {
							if(!resultMap.isEmpty()) {
								for(int p=from; p<pointer; p++) {
									final NTProcess process = resultMap.remove(p);
									
									//
									if(toFolder!=null) {
										final Display disp = Display.getCurrent();
										final String fname = process.getInputFilename(true);
										final String traceOutPath = String.format("%s%s-trace", toFolder, fname);
										final Image traceImage = process.drawModels(disp, COLOR_SEED, COLOR_BRANCH, COLOR_LINE, 1);
										
										NTUtil.saveAs(traceImage, traceOutPath, NTUtil.DEFAULT_IMAGE_EXTENSION);
										nodeTable.addInput(process);
									}
									
									logTable.appendItem(process);
									for(NTModel model: process.getModels()) {
										if(1<model.getTotalLength()) {
											modelTable.appendItem(process, model);
										}
									}
								}
								
								procLabel.setText(String.format("%s [%d/%d]", pstack.get(pointer-1).getName(), pointer-1, pstackSize));
								from = pointer;
								
								procBar.setSelection(pointer+1);
							}
							else {
								try {
									Thread.sleep(500);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
							}
							
							final int _newSize = pstack.size();
							if(pstackSize != _newSize) {
								procBar.setSelection(procBar.getSelection()+pstackSize - _newSize);
								pstackSize = _newSize;
							}
						}
						
						procBar.setSelection(0);
						procBar.setEnabled(false);
						logTable.refresh();
						modelTable.refresh();
						
						procLabel.setText("Completed");
						processBtn.setEnabled(true);
						processBtn.setText("START");
						
						if(toFolder!=null) {
							final String summaryOut = String.format("%s%s-summary", toFolder, _file.getName());
							final String modelsOut = String.format("%s%s-models", toFolder, _file.getName());
							logTable.saveAsText(summaryOut);
							modelTable.saveAsText(modelsOut);
							
							final String nodesOut = String.format("%s%s-nodes.txt", toFolder, _file.getName());
							NTUtil.saveAs(nodeTable.getCustomBuffer(), nodesOut, null);
						}
					}
				}
			});
		}
	};
	
	private ITableLabelProvider labelProvider = new ITableLabelProvider() {
		@Override
		public void removeListener(ILabelProviderListener listener) { }
		@Override
		public boolean isLabelProperty(Object element, String property) { return false;	}
		@Override
		public void dispose() { }
		@Override
		public void addListener(ILabelProviderListener listener) { }

		
		@Override
		public Image getColumnImage(Object element, int columnIndex) {
			return null;
		}

		@Override
		public String getColumnText(Object element, int columnIndex) {
			if(element instanceof File) {
				final File fin = (File) element;
				switch(columnIndex) {
				case 0:
					return fin.getName();
				case 1:
					return NTView.getExtension(fin);
				default:
					return null;
				}
			}
			return null;
		}
		
	};
	
	private ViewerFilter patternFilter = new ViewerFilter() {
		@Override
		public boolean select(Viewer viewer, Object parentElement, Object element) {
			if(selectAllBtn.getSelection())
				selectAllBtn.setSelection(false);
			
			if( element instanceof File && filterText.getData() instanceof Pattern) {
				final Pattern pattern = (Pattern) filterText.getData();
				final String fname = ((File)element).getName();
				return filterModeBtn.getSelection()!=pattern.matcher(fname).find();
			} else {
				return true;
			}
		}
	};
}
