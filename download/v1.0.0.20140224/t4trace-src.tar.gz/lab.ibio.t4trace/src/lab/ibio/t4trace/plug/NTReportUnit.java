package lab.ibio.t4trace.plug;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.TreeMap;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Composite;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public abstract class NTReportUnit {
	// initialize
	private static HashMap<String, NTReportUnit> _workers;
	{
		for(TAG t : TAG.values()) {
			_workers.put(t.name().toUpperCase(), t.unit);
		}
	}
	
	public static void registerWorker(String tagName, NTReportUnit worker) {
		if(_workers==null)
			_workers = new HashMap<String, NTReportUnit>();
		
		_workers.put(tagName, worker);
	}
	
	public static void drawScreen(Composite root, Document xml) {
		final Composite reportWrapper = new Composite(root, SWT.NONE);
		final TreeMap<Element, Composite> processStack = new TreeMap<Element, Composite>();
		processStack.put(xml.getDocumentElement(), reportWrapper);
		
		while(!processStack.isEmpty()) {
			final Element element = processStack.lastKey();
			final Composite comp = processStack.remove(element); // remove here
			final String tag = element.getTagName().toUpperCase();
			
			final NTReportUnit worker = _workers.get(tag);			
			final Composite maden = worker.draw(comp, element);
			if(element.hasChildNodes()) {
				NodeList nodes = element.getChildNodes();
				for(int i=0; i<nodes.getLength(); i++) {
					if(nodes.item(i) instanceof Element
					&& _workers.containsKey(((Element)nodes.item(i)).getTagName().toUpperCase()))
						processStack.put((Element)nodes.item(i), maden);
				}
			}
		}
	}
	
	public static void writeFile(OutputStream os, Document xml) {
		final ArrayList<Element> processStack = new ArrayList<Element>();
		
		while(!processStack.isEmpty()) {
			final Element element = processStack.remove(processStack.size()-1);
			final NTReportUnit worker = _workers.get(element.getTagName());
			
			try {
				os.write(worker.write(element).getBytes());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	protected abstract Composite draw(Composite parent, Element xml);
	protected abstract String write(Element xml);
	
	public enum TAG {
		root(UNIT_ROOT),
		section(UNIT_SECTION),
		text(UNIT_TEXT),
		table(UNIT_TABLE),
		graphic(UNIT_GRAPHIC),
		
		;
		NTReportUnit unit;
		TAG(NTReportUnit u) { this.unit = u; }
		public String toString() { return this.name().toUpperCase(); }
	}
	
	public static NTReportUnit UNIT_ROOT = new NTReportUnit() {
		@Override
		protected String write(Element xml) {
			return null;
		}
		
		@Override
		protected Composite draw(Composite parent, Element xml) {
			return null;
		}
	};
	
	public static NTReportUnit UNIT_SECTION = new NTReportUnit() {
		
		@Override
		protected String write(Element xml) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		protected Composite draw(Composite parent, Element xml) {
			// TODO Auto-generated method stub
			return null;
		}
	};
	
	public static NTReportUnit UNIT_TEXT = new NTReportUnit() {
		
		@Override
		protected String write(Element xml) {
			// TODO Auto-generated method stub
			return null;
		}
		
		@Override
		protected Composite draw(Composite parent, Element xml) {
			// TODO Auto-generated method stub
			return null;
		}
	};
	
	public static NTReportUnit UNIT_TABLE = new NTReportUnit() {
		
		@Override
		protected String write(Element xml) {
			return null;
		}
		
		@Override
		protected Composite draw(Composite parent, Element xml) {
			return null;
		}
	};
	
	public static NTReportUnit UNIT_GRAPHIC = new NTReportUnit() {
		@Override
		protected Composite draw(Composite parent, Element xml) {
			return null;
		}

		@Override
		protected String write(Element xml) {
			return null;
		}
	};
	
	public static NTReportUnit UNIT_CHART_BAR = new NTReportUnit() {
		@Override
		protected String write(Element xml) {
			return null;
		}
		
		@Override
		protected Composite draw(Composite parent, Element xml) {
			return null;
		}
	};
	
	public static NTReportUnit UNIT_CHART_LINE = new NTReportUnit() {

		@Override
		protected Composite draw(Composite parent, Element xml) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		protected String write(Element xml) {
			// TODO Auto-generated method stub
			return null;
		}
		
	};
	

}
