package lab.ibio.t4trace.view;

import java.io.File;

import lab.ibio.t4trace.plug.NTView;
import lab.ibio.t4trace.workbench.Activator;
import lab.ibio.t4trace.workbench.Application;
import lab.ibio.t4trace.workbench.NTPreference;

import org.eclipse.jface.viewers.DoubleClickEvent;
import org.eclipse.jface.viewers.IDoubleClickListener;
import org.eclipse.jface.viewers.IStructuredContentProvider;
import org.eclipse.jface.viewers.ITreeContentProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreeSelection;
import org.eclipse.jface.viewers.TreeViewer;
import org.eclipse.jface.viewers.Viewer;
import org.eclipse.swt.SWT;
import org.eclipse.swt.graphics.Image;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.ISharedImages;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.part.ViewPart;

public class NavigationView extends ViewPart {
	public static final String ID = "lab.ibio.t4trace.navigationView";
	
	private TreeViewer viewer;
	

	public boolean goNext(File file) {
		return file.isDirectory();
	}

	/**
     * This is a callback that will allow us to create the viewer and initialize it.
     */
	public void createPartControl(Composite parent) {
		this.viewer = new TreeViewer(parent, SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL | SWT.BORDER);
		viewer.setContentProvider(new ViewContentProvider());
		viewer.setLabelProvider(new ViewLabelProvider());
		
		viewer.addDoubleClickListener(new IDoubleClickListener() {
			@Override
			public void doubleClick(DoubleClickEvent event) {
				final TreeSelection selection = (TreeSelection) event.getSelection();
				final File fin = (File) selection.getFirstElement();
				try {
					final String viewId = NTView.getFirstViewId(fin);
					final String secondaryId = NTView.file2IdString(fin);
					// accept default
					if(viewId!=null)
						Application.activePage().showView(viewId, secondaryId, IWorkbenchPage.VIEW_ACTIVATE);
				} catch (PartInitException e) {
					e.printStackTrace();
				} catch (NullPointerException ex) {
					ex.printStackTrace();
				}
				
			}
		});
		
		final String workspacePath = NTPreference.getString(NTPreference.WORKSPACE); 
		if(workspacePath!=null) {
			final File space = new File(workspacePath);
			if(space.isDirectory() && space.canWrite())
				setWorkspace(space);
		}
		
		if(viewer.getInput()==null) {
			setWorkspace(new File("."));
		}
	}
	
	public void setWorkspace(File space) {
		viewer.setInput(space.getAbsolutePath());
	}

	/**
	 * Passing the focus request to the viewer's control.
	 */
	public void setFocus() {
		viewer.getControl().setFocus();
		viewer.refresh();
	}
	
	/*
	 * internal use native classes
	 */
	class ViewContentProvider 
	implements IStructuredContentProvider, ITreeContentProvider {
		public void inputChanged(Viewer v, Object oldInput, Object newInput) { /* do nothing */	}
		public void dispose() { /* do nothing */ }
		public Object getParent(Object child) { return null; }
    
		public Object[] getElements(Object parent) {
			if(parent instanceof String) {
				return new Object[]{new File((String)parent)};
			}
			else if(parent instanceof File) {
				return getChildren(parent);
			}
			return null;
		}
	    
		public Object[] getChildren(Object parent) {
			if (parent instanceof File && ((File)parent).isDirectory()) {
				return ((File)parent).listFiles(NTView.NTFilter);
			}
			return new Object[0];
		}
	
	    public boolean hasChildren(Object parent) {
			return (parent instanceof String)
				|| ((parent instanceof File) && ((File)parent).isDirectory());
		}
	}
	
	class ViewLabelProvider extends LabelProvider {
	
		public String getText(Object obj) {
			if(obj instanceof String)
				return (String)obj;
			else if(obj instanceof File)
				return ((File)obj).getName();
			else
				return obj.toString();
		}
		public Image getImage(Object obj) {
			String imageKey = ISharedImages.IMG_OBJS_WARN_TSK;
			if(obj instanceof String)
				imageKey = ISharedImages.IMG_OBJ_FOLDER;
			else if(obj instanceof File) {
				final File file = (File)obj;
	
				if(file.isDirectory()) {
					imageKey = ISharedImages.IMG_OBJ_FOLDER;
				}
				else if(NTView.getFirstViewId(file)!=null) {
					return Activator.getDefault().getImageRegistry().get(NTView.getFirstViewId(file));
				}
			}
			
			return PlatformUI.getWorkbench().getSharedImages().getImage(imageKey);
		}
	}

}